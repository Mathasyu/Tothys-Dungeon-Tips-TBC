--[[
Tothys Dungeon Tips TBC (former QE Dungeon Tips)
Configuration Page

Version: 0.9.3
Developed by: Voulk
Forked by: Mathasyu 2026-03-09
Contact:
	Discord: Voulk#1858
	Email: itsvoulk@gmail.com
Changelog:
    0.9 - 2026-03-09
        - The Addon works now in the TBC Anniversary Client
        - New Slash Commands: /kdt config, /kdt show, /kdt hide, /kdt test
    0.9.1 - 2026-03-22
        - Added /kdt toggle
        - Added /kdt lang <auto|en|de>
        - Renamed to Kiesel Dungeon Tool
        - Added Content Browser, Dungeon Editor, Tip Editor, and Info pages
        - Added locale-aware UI text and language switching
        - Added personal NPC and dungeon notes with safe user-data storage
        - Added override, hide, and reset workflows for shipped tips
        - Added scrollbars for the main tip window and config/editor pages
        - Expanded TBC dungeon and raid catalog with editor-safe tip IDs and weights
    0.9.3 - 2026-03-29
        - Split the browser into Dungeon-Browser and NPC-Browser
        - Renamed editors to NPC-Editor and Dungeon-Editor
        - Added the minimap button and the >>> quick jump to NPC-Browser
        - Finished structural multilingual cleanup for tipsMap_deDE
        - Added translation audit and paired EN/DE review exports
        - Added a normalized content-model export as groundwork for the new addon rewrite
]]--

local localeDisplayNames = {
    Auto = "Auto",
    enUS = "English",
    deDE = "Deutsch",
}

local browserLocaleStrings = {
	enUS = {
		content_browser_page = "Dungeon-Browser",
		content_browser_title = "Kiesel Dungeon Tool - Dungeon-Browser",
		content_browser_subtitle = "Browse expansion, dungeon, and raid information here. This page focuses on dungeon overviews and keeps NPC details out of the way.",
		npc_browser_page = "NPC-Browser",
		npc_browser_title = "Kiesel Dungeon Tool - NPC-Browser",
		npc_browser_subtitle = "Browse NPC tips here. Use Selection to choose an NPC and review notes. The Abilities tab is reserved for future boss ability entries.",
		npc_browser_tab_selection = "Selection",
		npc_browser_tab_abilities = "Abilities",
		npc_browser_abilities_placeholder = "No ability entries for this NPC yet.",
		config_page = "Kiesel Dungeon Tool",
		config_title = "Kiesel Dungeon Tool - Config",
		info_title = "Kiesel Dungeon Tool - Info",
		info_intro = "Kiesel Dungeon Tool is a successor to QE Dungeon Tips.",
		info_background = "Background",
		info_background_text = "QE Dungeon Tips did great groundwork and provided the base inspiration for this addon. The original project helped establish the structure and the idea of contextual dungeon and NPC guidance.\n\nThis addon exists because QE Dungeon Tips no longer worked reliably for TBC Anniversary, so we are rebuilding and extending the concept in a form that fits the current project goals.",
		info_status = "Project Status",
		info_status_text = "Kiesel Dungeon Tool is still actively in development and is not complete yet.\n\nSome instances and NPCs are already structured in the new browser and data model, but the addon is still being expanded, cleaned up, and documented. Expect missing content, placeholder areas, and ongoing iteration while the new system is built out.",
		info_focus = "Current Focus",
		info_focus_text = "Current work focuses on:\n- structured expansion, instance, and NPC browsing\n- tactical dungeon info and browser-only extra details\n- locale-aware data handling\n- update-safe personal editing and overrides",
		info_feedback = "Feedback",
		info_feedback_text = "Some of the newer raid overview texts were AI-generated as a first draft and still need review. If you spot mistakes or unclear wording, please report them through the project's GitHub issue tracker.\n\nThe preferred workflow is to improve the text inside the addon first and then export the corrected strings later, once export support is available.",
		locale_reload_text = "Changing the language will reload the UI. Continue?",
		locale_reload_accept = "Reload UI",
		locale_reload_cancel = "Cancel",
		info_how_it_works_text = "|cffd9a64aDungeon and NPC-Browser|r\nUse `Dungeon-Browser` to look up dungeon and raid overview data. Use `NPC-Browser` to browse NPC-specific tips without mixing them into the instance overview.\n\n|cffd9a64aDungeon and NPC-Editor|r\n`Dungeon-Editor` is for instance-wide notes and `More Infos`. `NPC-Editor` is for NPC-specific tips. `Addon Tips` are the built-in notes that come with the addon. They can be adjusted or hidden without changing the original addon data. `Personal Tips` are your own notes.\n\n|cffd9a64aWeighting|r\nWeight controls the order of tips. Higher values appear first. The built-in addon tips usually start at `10` and go up in steps of `10`, which makes it easy to place your own notes in between them when needed.\n\n|cffd9a64aQuick jump to the current NPC|r\nThe `>>>` button in the main window jumps straight to `NPC-Browser` and preselects the NPC currently shown there when available.",
		additional_details = "More Infos",
		add_npc_tip = "Add Personal NPC Tip",
		editor_page = "NPC-Editor",
		editor_title = "Kiesel Dungeon Tool - NPC-Editor",
		editor_subtitle = "Add your own NPC tips or adjust existing addon tips here. This is useful for raid leads, group notes, and encounter reminders.",
		dungeon_editor_page = "Dungeon-Editor",
		dungeon_editor_title = "Kiesel Dungeon Tool - Dungeon-Editor",
		dungeon_editor_subtitle = "Add your own dungeon notes or adjust existing dungeon info here. This is useful for route notes, reminders, and group preparation.",
		add_instance_tip = "Add Personal Dungeon Tip",
		instance_tips_preview = "Dungeon Tips",
		instance_summary_prefix = "Selected",
		user_instance_tips = "Personal Dungeon Tips",
		addon_instance_tips = "Addon Dungeon Tips",
		no_addon_instance_tips = "No addon dungeon tips found for this dungeon or raid.",
		no_user_instance_tips = "No personal dungeon tips for this dungeon or raid yet.",
		saved_instance_tip = "Personal dungeon tip saved.",
		updated_instance_tip = "Personal dungeon tip updated.",
		instance_edit_loaded = "Personal dungeon tip loaded into editor.",
		base_instance_edit_loaded = "Addon dungeon tip loaded into override mode.",
		updated_base_instance_tip = "Addon dungeon tip override updated.",
		edit_more_infos = "Edit More Infos",
		save_more_infos = "Save More Infos",
		reset_more_infos = "Reset More Infos",
		more_infos_saved = "More Infos overrides saved.",
		more_infos_reset = "More Infos overrides reset.",
		original_text = "Original",
		tip_type = "Tip Type",
		tip_weight = "Weight",
		tip_text = "Tip Text",
		save_tip = "Save Tip",
		edit = "Edit",
		edit_base = "Override",
		update_tip = "Update Tip",
		update_base_tip = "Save Override",
		cancel_edit = "Cancel Edit",
		edit_loaded = "Personal tip loaded into editor.",
		base_edit_loaded = "Base tip loaded into editor override mode.",
		updated_tip = "Personal tip updated.",
		updated_base_tip = "Base tip override updated.",
		personal_tips = "User Tips",
		base_tips = "Addon Tips",
		no_base_tips = "No addon tips found for this NPC.",
		no_dungeon_tips = "No addon dungeon tips found for this dungeon yet.",
		reset = "Reset",
		overridden_tip = "overridden",
		legacy_tip = "legacy read-only",
		hidden_tip = "hidden",
		hide = "Hide",
		unhide = "Unhide",
		delete = "Delete",
		no_personal_tips = "No personal tips for this NPC yet.",
		default_tip_text = "Write a personal NPC tip here...",
		default_instance_tip_text = "Write a personal dungeon tip here...",
		saved_tip = "Personal NPC tip saved.",
		missing_tip = "Please choose a tip type and enter text first.",
		travel = "Travel",
		attunement = "Attunement",
		extra_notes = "More Infos",
		lore = "Lore / RP",
		no_details = "No extra dungeon info yet.",
		select_npc_to_view = "Select an NPC to view tips.",
		info_page = "Info",
		dungeon_info = "Dungeon Info",
		npc_tips = "NPC Tips",
		info_how_it_works = "How It Works",
		info_slash_commands = "Slash Commands",
		info_slash_commands_text = "Use these commands in chat:\n- /kdt config opens the addon settings\n- /kdt show shows the main window\n- /kdt hide hides the main window\n- /kdt toggle toggles the main window\n- /kdt test shows a test preview\n- /kdt lang auto switches to Auto\n- /kdt lang en switches to English\n- /kdt lang de switches to German",
		info_frame_clicks = "Quick NPC Jump",
		info_frame_clicks_text = "The `>>>` button in the main window jumps straight to `NPC-Browser` and preselects the NPC currently shown there when available.",
		expansion = "Expansion",
		dungeon_or_raid = "Dungeon / Raid",
		npc = "NPC",
		bosses = "Bosses",
		npc_ids = "NPC IDs",
		npcs_a_i = "NPCs A-I",
		npcs_j_r = "NPCs J-R",
		npcs_s_z = "NPCs S-Z",
		instance_group_hellfire_peninsula = "--- Hellfire Peninsula ---",
		instance_group_terokkar_forest = "--- Terokkar Forest ---",
		instance_group_zangarmarsh = "--- Zangarmarsh ---",
		instance_group_caverns_of_time = "--- Caverns of Time ---",
		instance_group_netherstorm = "--- Netherstorm ---",
		instance_group_isle_of_queldanas = "--- Isle of Quel'Danas ---",
		instance_group_raids = "--- Raids ---",
		selected_with_type = "Selected: %s -> %s (%s) -> %s",
		selected_npc_path = "Selected: %s -> %s -> %s",
		selected_npc = "NPC: %s",
		selected_instance = "Selected: %s -> %s",
		config_tip_location = "Tip Location",
		config_show_separate_frame = "Show tips in separate frame",
		config_show_prefix = "Show",
		config_show_separate_frame_tooltip = "Uncheck to have tips appear in mob tooltips instead",
		config_show_frame = "Show Frame",
		config_hide_frame = "Hide Frame",
		config_target_mouseover = "Show Target or Mouseover",
		config_show_target = "Show Targeted Mob",
		config_role_specific = "Role Specific Tips",
		config_show_myroleonly = "Show My Role Only",
		config_show_tank = "Show Tank",
		config_show_healer = "Show Healer",
		config_show_damage = "Show Damage Dealer",
		config_class_specific = "Class Specific Tips",
		config_show_myclassonly = "Show My Class Only",
		class_druid = "Druid",
		class_hunter = "Hunter",
		class_mage = "Mage",
		class_paladin = "Paladin",
		class_priest = "Priest",
		class_rogue = "Rogue",
		class_shaman = "Shaman",
		class_warrior = "Warrior",
		class_warlock = "Warlock",
		config_language = "Language",
		config_language_help = "Auto uses the client locale. English is the fallback if no translation exists.",
		config_content = "Content",
		config_show_in_dungeons = "Show Tips in Dungeons",
		config_show_in_raid = "Show Tips in Raid",
		config_minimap_button = "Minimap Button",
		config_show_minimap_button = "Show Minimap Button",
		config_hide_minimap_button = "Hide Minimap Button",
		config_show_npc_ids = "Show NPC IDs",
		config_font_size = "Font Size",
		config_general = "Show Important General Information",
		config_priority = "Show Priority Targets",
		config_interrupts = "Show Priority Interrupts",
		config_defensives = "Show Defensive Recommendations",
		config_fluff = "Show Fluff/RP",
		config_advanced = "Show advanced tips for high level keys",
		config_personal = "Show Personal Notes",
	},
	deDE = {
		content_browser_page = "Dungeon-Browser",
		content_browser_title = "Kiesel Dungeon Tool - Dungeon-Browser",
		content_browser_subtitle = "Hier kannst du Erweiterungen, Dungeons und Raids durchsehen. Diese Seite konzentriert sich auf Dungeon-Infos, ohne NPC-Inhalte dazwischen.",
		npc_browser_page = "NPC-Browser",
		npc_browser_title = "Kiesel Dungeon Tool - NPC-Browser",
		npc_browser_subtitle = "Hier kannst du NPC-Tipps durchsehen. Unter Auswahl waehlst du den NPC, unter Abilities koennen spaeter Boss-Faehigkeiten stehen.",
		npc_browser_tab_selection = "Auswahl",
		npc_browser_tab_abilities = "Abilities",
		npc_browser_abilities_placeholder = "Fuer diesen NPC gibt es noch keine Ability-Eintraege.",
		config_page = "Kiesel Dungeon Tool",
		config_title = "Kiesel Dungeon Tool - Konfiguration",
		info_title = "Kiesel Dungeon Tool - Info",
		info_intro = "Kiesel Dungeon Tool ist ein Nachfolger von QE Dungeon Tips.",
		info_background = "Hintergrund",
		info_background_text = "QE Dungeon Tips hat tolle Vorarbeit geleistet und die Grundlage fuer dieses Addon geschaffen. Das urspruengliche Projekt hat die Idee von kontextbezogenen Dungeon- und NPC-Hinweisen etabliert.\n\nDieses Addon existiert, weil QE Dungeon Tips fuer TBC Anniversary nicht mehr verlaesslich funktioniert hat. Deshalb bauen wir das Konzept in einer Form neu auf und erweitern es weiter, die besser zu den heutigen Projektzielen passt.",
		info_status = "Projektstatus",
		info_status_text = "Kiesel Dungeon Tool ist weiterhin aktiv in Entwicklung und noch nicht vollstaendig.\n\nEinige Instanzen und NPCs sind bereits in der neuen Browser- und Datenstruktur vorhanden, aber das Addon wird noch weiter ausgebaut, bereinigt und dokumentiert. Es ist also normal, wenn Inhalte fehlen oder sich noch veraendern.",
		info_focus = "Aktueller Fokus",
		info_focus_text = "Der aktuelle Fokus liegt auf:\n- strukturierter Navigation fuer Erweiterungen, Instanzen und NPCs\n- taktischen Dungeon-Infos und zusaetzlichen Browser-Infos\n- lokalisierungsfaehigen Daten\n- updatesicheren persoenlichen Bearbeitungen und Overrides",
		info_feedback = "Feedback",
		info_feedback_text = "Ein Teil der neueren Raid-Uebersichtstexte wurde zunaechst mit AI erstellt und muss noch geprueft werden. Wenn dir Fehler oder unklare Formulierungen auffallen, melde sie bitte ueber den GitHub-Issue-Tracker des Projekts.\n\nDer bevorzugte Ablauf ist, Texte zuerst direkt im Addon zu verbessern und die korrigierten Strings spaeter zu exportieren, sobald die Exportfunktion vorhanden ist.",
		locale_reload_text = "Das Aendern der Sprache laedt das Interface neu. Fortfahren?",
		locale_reload_accept = "Interface neu laden",
		locale_reload_cancel = "Abbrechen",
		info_how_it_works_text = "|cffd9a64aDungeon- und NPC-Browser|r\nIm `Dungeon-Browser` kannst du Dungeon- und Raid-Uebersichten nachschlagen. Im `NPC-Browser` findest du gezielt NPC-Tipps, ohne dass sie zwischen den Instanzinfos untergehen.\n\n|cffd9a64aDungeon- und NPC-Editor|r\nDer `Dungeon-Editor` ist fuer instanzweite Hinweise und `Mehr Infos`. Der `NPC-Editor` ist fuer NPC-spezifische Tipps. `Addon-Tipps` sind die eingebauten Hinweise des Addons. Sie koennen angepasst oder ausgeblendet werden, ohne die urspruenglichen Addon-Daten zu veraendern. `Persoenliche Tipps` sind deine eigenen Notizen.\n\n|cffd9a64aGewichtung|r\nDie Gewichtung steuert die Reihenfolge der Tipps. Hoehere Werte erscheinen weiter oben. Die eingebauten Addon-Tipps beginnen meist bei `10` und steigen in `10`er-Schritten, damit du eigene Notizen leicht dazwischen einsortieren kannst.\n\n|cffd9a64aSchnellsprung zum momentanen NPC|r\nDer `>>>`-Button im Hauptfenster springt direkt in den `NPC-Browser` und waehlt dort, wenn moeglich, genau den NPC aus, der gerade im Fenster angezeigt wird.",
		additional_details = "Mehr Infos",
		add_npc_tip = "Persoenlichen NPC-Tipp hinzufuegen",
		editor_page = "NPC-Editor",
		editor_title = "Kiesel Dungeon Tool - NPC-Editor",
		editor_subtitle = "Hier kannst du eigene NPC-Tipps hinzufuegen oder vorhandene Addon-Tipps anpassen. Ideal fuer Raid-Leads, Gruppennotizen und Begegnungserinnerungen.",
		dungeon_editor_page = "Dungeon-Editor",
		dungeon_editor_title = "Kiesel Dungeon Tool - Dungeon-Editor",
		dungeon_editor_subtitle = "Hier kannst du eigene Dungeon-Notizen hinzufuegen oder vorhandene Dungeon-Infos anpassen. Ideal fuer Routen, Erinnerungen und Gruppenvorbereitung.",
		add_instance_tip = "Persoenlichen Dungeon-Tipp hinzufuegen",
		instance_tips_preview = "Dungeon-Tipps",
		instance_summary_prefix = "Ausgewaehlt",
		user_instance_tips = "Persoenliche Dungeon-Tipps",
		addon_instance_tips = "Addon-Dungeon-Tipps",
		no_addon_instance_tips = "Fuer diesen Dungeon oder Raid wurden keine Addon-Dungeon-Tipps gefunden.",
		no_user_instance_tips = "Fuer diesen Dungeon oder Raid gibt es noch keine persoenlichen Dungeon-Tipps.",
		saved_instance_tip = "Persoenlicher Dungeon-Tipp gespeichert.",
		updated_instance_tip = "Persoenlicher Dungeon-Tipp aktualisiert.",
		instance_edit_loaded = "Persoenlicher Dungeon-Tipp in den Editor geladen.",
		base_instance_edit_loaded = "Addon-Dungeon-Tipp im Ueberschreibungsmodus geladen.",
		updated_base_instance_tip = "Addon-Dungeon-Tipp-Ueberschreibung aktualisiert.",
		edit_more_infos = "Mehr Infos bearbeiten",
		save_more_infos = "Mehr Infos speichern",
		reset_more_infos = "Mehr Infos zuruecksetzen",
		more_infos_saved = "Mehr-Infos-Overrides gespeichert.",
		more_infos_reset = "Mehr-Infos-Overrides zurueckgesetzt.",
		original_text = "Original",
		tip_type = "Tipp-Typ",
		tip_weight = "Gewichtung",
		tip_text = "Tipp-Text",
		save_tip = "Tipp speichern",
		edit = "Bearbeiten",
		edit_base = "Ueberschreiben",
		update_tip = "Tipp aktualisieren",
		update_base_tip = "Ueberschreibung speichern",
		cancel_edit = "Bearbeiten abbrechen",
		edit_loaded = "Persoenlicher Tipp in den Editor geladen.",
		base_edit_loaded = "Basis-Tipp im Ueberschreibungsmodus geladen.",
		updated_tip = "Persoenlicher Tipp aktualisiert.",
		updated_base_tip = "Basis-Tipp-Ueberschreibung aktualisiert.",
		personal_tips = "Eigene Tipps",
		base_tips = "Addon-Tipps",
		no_base_tips = "Fuer diesen NPC wurden keine Addon-Tipps gefunden.",
		no_dungeon_tips = "Fuer diesen Dungeon wurden noch keine Addon-Dungeontipps gefunden.",
		reset = "Zuruecksetzen",
		overridden_tip = "ueberschrieben",
		legacy_tip = "Altes Format, schreibgeschuetzt",
		hidden_tip = "ausgeblendet",
		hide = "Ausblenden",
		unhide = "Einblenden",
		delete = "Loeschen",
		no_personal_tips = "Fuer diesen NPC gibt es noch keine persoenlichen Tipps.",
		default_tip_text = "Hier persoenlichen NPC-Tipp eingeben...",
		default_instance_tip_text = "Hier persoenlichen Dungeon-Tipp eingeben...",
		saved_tip = "Persoenlicher NPC-Tipp gespeichert.",
		missing_tip = "Bitte zuerst einen Tipp-Typ waehlen und Text eingeben.",
		travel = "Anfahrt",
		attunement = "Zugang",
		extra_notes = "Mehr Infos",
		lore = "Lore / RP",
		no_details = "Noch keine zusaetzlichen Dungeon-Infos vorhanden.",
		select_npc_to_view = "Waehle einen NPC aus, um Tipps zu sehen.",
		info_page = "Info",
		dungeon_info = "Dungeon-Infos",
		npc_tips = "NPC-Tipps",
		info_how_it_works = "So funktioniert's",
		info_slash_commands = "Slashbefehle",
		info_slash_commands_text = "Diese Befehle kannst du im Chat verwenden:\n- /kdt config oeffnet die Addon-Einstellungen\n- /kdt show zeigt das Hauptfenster\n- /kdt hide blendet das Hauptfenster aus\n- /kdt toggle schaltet das Hauptfenster um\n- /kdt test zeigt eine Testvorschau\n- /kdt lang auto schaltet auf Auto\n- /kdt lang en schaltet auf Englisch\n- /kdt lang de schaltet auf Deutsch",
		info_frame_clicks = "Schnellsprung zum NPC",
		info_frame_clicks_text = "Der `>>>`-Button im Hauptfenster springt direkt in den `NPC-Browser` und waehlt dort, wenn moeglich, genau den NPC aus, der gerade im Fenster angezeigt wird.",
		expansion = "Erweiterung",
		dungeon_or_raid = "Dungeon / Raid",
		npc = "NPC",
		bosses = "Bosse",
		npc_ids = "NPC-IDs",
		npcs_a_i = "NPCs A-I",
		npcs_j_r = "NPCs J-R",
		npcs_s_z = "NPCs S-Z",
		instance_group_hellfire_peninsula = "--- Höllenfeuerhalbinsel ---",
		instance_group_terokkar_forest = "--- Wälder von Terokkar ---",
		instance_group_zangarmarsh = "--- Zangarmarschen ---",
		instance_group_caverns_of_time = "--- Höhlen der Zeit ---",
		instance_group_netherstorm = "--- Nethersturm ---",
		instance_group_isle_of_queldanas = "--- Insel von Quel'Danas ---",
		instance_group_raids = "--- Raids ---",
		selected_with_type = "Ausgewaehlt: %s -> %s (%s) -> %s",
		selected_npc_path = "Ausgewaehlt: %s -> %s -> %s",
		selected_npc = "NPC: %s",
		selected_instance = "Ausgewaehlt: %s -> %s",
		config_tip_location = "Anzeigeort",
		config_show_separate_frame = "Tipps in separatem Fenster anzeigen",
		config_show_prefix = "Zeige",
		config_show_separate_frame_tooltip = "Deaktivieren, damit Tipps direkt in Mob-Tooltips erscheinen",
		config_show_frame = "Fenster zeigen",
		config_hide_frame = "Fenster verbergen",
		config_target_mouseover = "Target oder Mouseover",
		config_show_target = "Anvisierten Mob anzeigen",
		config_role_specific = "Rollenspezifische Tipps",
		config_show_myroleonly = "Nur meine Rolle anzeigen",
		config_show_tank = "Tank anzeigen",
		config_show_healer = "Heiler anzeigen",
		config_show_damage = "Schadensausteiler anzeigen",
		config_class_specific = "Klassenspezifische Tipps",
		config_show_myclassonly = "Nur meine Klasse anzeigen",
		class_druid = "Druide",
		class_hunter = "Jaeger",
		class_mage = "Magier",
		class_paladin = "Paladin",
		class_priest = "Priester",
		class_rogue = "Schurke",
		class_shaman = "Schamane",
		class_warrior = "Krieger",
		class_warlock = "Hexenmeister",
		config_language = "Sprache",
		config_language_help = "Auto verwendet die Sprache des Spiels. Englisch wird verwendet, wenn keine Uebersetzung vorhanden ist.",
		config_content = "Inhalte",
		config_show_in_dungeons = "Tipps in Dungeons anzeigen",
		config_show_in_raid = "Tipps in Raids anzeigen",
		config_minimap_button = "Minimap-Button",
		config_show_minimap_button = "Minimap-Button anzeigen",
		config_hide_minimap_button = "Minimap-Button ausblenden",
		config_show_npc_ids = "NPC-IDs anzeigen",
		config_font_size = "Schriftgroesse",
		config_general = "Wichtige allgemeine Hinweise anzeigen",
		config_priority = "Prioritaetsziele anzeigen",
		config_interrupts = "Wichtige Unterbrechungen anzeigen",
		config_defensives = "Defensiv-Empfehlungen anzeigen",
		config_fluff = "Fluff / RP anzeigen",
		config_advanced = "Fortgeschrittene Tipps fuer schwere Inhalte anzeigen",
		config_personal = "Persoenliche Notizen anzeigen",
	},
}

local browserIconList = {
    PriorityTargets = "ability_hunter_snipershot",
    Interrupts = "ability_kick",
    Defensives = "inv_shield_05",
    Important = "ability_dualwield",
    Legion = "ability_dualwield",
    Dodge = "ability_dualwield",
    Personal = "inv_misc_note_01",
    DRUID = "classicon_druid",
    HUNTER = "classicon_hunter",
    MAGE = "classicon_mage",
    MONK = "classicon_monk",
    PALADIN = "classicon_paladin",
    PRIEST = "classicon_priest",
    ROGUE = "classicon_rogue",
    SHAMAN = "classicon_shaman",
    WARRIOR = "classicon_warrior",
    WARLOCK = "classicon_warlock",
    HEALER = "spell_nature_healingtouch",
    TANK = "inv_shield_06",
    DAMAGE = "inv_sword_01",
}

local browserTypeColors = {
    Legion = {0.8, 0.8, 0.8},
    Important = {1, 0, 0},
    Defensives = {1, 0.57, 0.12},
    Interrupts = {0.37, 0.92, 1},
    Dodge = {0.54, 0.81, 0.94},
    PriorityTargets = {1, 1, 0},
    Fluff = {1, 1, 1},
    Advanced = {0.75, 0.55, 0.35},
    Personal = {1, 0.84, 0},
    TANK = {0.78, 0.61, 0.43},
    HEALER = {0, 1, 0.59},
    DAMAGE = {1, 0.72, 0.72},
}

local NPC_NONE = "__none__"
local INSTANCE_GROUP_PREFIX = "__group__:"
local isInstanceGroupEntry
local makeInstanceGroupEntry
local getInstanceGroupLabel
local getFirstSelectableValue

local groupedTbcInstanceKeys = {
	{
		label = "instance_group_hellfire_peninsula",
		instances = { "hellfire_ramparts", "blood_furnace", "shattered_halls" },
	},
	{
		label = "instance_group_terokkar_forest",
		instances = { "mana_tombs", "auchenai_crypts", "sethekk_halls", "shadow_labyrinth" },
	},
	{
		label = "instance_group_zangarmarsh",
		instances = { "slave_pens", "underbog", "steamvaults" },
	},
	{
		label = "instance_group_caverns_of_time",
		instances = { "old_hillsbrad", "black_morass" },
	},
	{
		label = "instance_group_netherstorm",
		instances = { "mechanar", "botanica", "arcatraz" },
	},
	{
		label = "instance_group_isle_of_queldanas",
		instances = { "magisters_terrace" },
	},
	{
		label = "instance_group_raids",
		instances = {
			"karazhan",
			"gruuls_lair",
			"magtheridons_lair",
			"zulaman",
			"serpentshrine_cavern",
			"tempest_keep_the_eye",
			"hyjal_summit",
			"black_temple",
			"sunwell_plateau",
		},
	},
}

local authorTipTypes = {
	"Important",
	"PriorityTargets",
	"Defensives",
	"Interrupts",
	"Dodge",
	"Advanced",
	"Personal",
	"HEALER",
	"TANK",
	"DAMAGE",
	"DRUID",
	"HUNTER",
	"MAGE",
	"PALADIN",
	"PRIEST",
	"ROGUE",
	"SHAMAN",
	"WARRIOR",
	"WARLOCK",
}

local function createCycleButton(frame, name, values, onChange)
    local button = CreateFrame("Button", "TDTButton" .. name, frame, "UIPanelButtonTemplate")
    button:SetWidth(140)
    button:SetHeight(24)
    button.values = values
    button.currentIndex = 1

    function button:SetValues(values)
        self.values = values or {}
        if self.currentIndex > #self.values then
            self.currentIndex = 1
        end
    end

    function button:SetCurrentValue(value)
        if not self.values or #self.values == 0 then
            self.currentIndex = 1
            self:SetText("-")
            return
        end

        for index, candidate in ipairs(self.values) do
            if candidate == value then
                self.currentIndex = index
                break
            end
        end

        local currentValue = self.values[self.currentIndex]
        local displayText
        if self.labelForValue then
            displayText = self.labelForValue(currentValue)
        end
        self:SetText(displayText or localeDisplayNames[currentValue] or currentValue)
    end

    button:SetScript("OnClick", function(self)
        if not self.values or #self.values == 0 then
            return
        end

        self.currentIndex = self.currentIndex + 1
        if self.currentIndex > #self.values then
            self.currentIndex = 1
        end

        local value = self.values[self.currentIndex]
        local displayText
        if self.labelForValue then
            displayText = self.labelForValue(value)
        end
        self:SetText(displayText or localeDisplayNames[value] or value)
        onChange(value)
    end)

    return button
end

local function createValueDropdown(frame, name, width, onChange)
    local dropdown = CreateFrame("Frame", "TDTDropdown" .. name, frame, "UIDropDownMenuTemplate")
    dropdown:SetWidth(width or 180)
    dropdown.values = {}
    dropdown.currentValue = nil

    function dropdown:SetValues(values)
        self.values = values or {}
    end

    function dropdown:SetCurrentValue(value)
        self.currentValue = value

        local label = "-"
        if value and self.labelForValue then
            label = self.labelForValue(value) or "-"
        elseif value then
            label = tostring(value)
        end

        UIDropDownMenu_SetText(self, label)
    end

    UIDropDownMenu_SetWidth(dropdown, width or 180)
    UIDropDownMenu_Initialize(dropdown, function(self, level)
        local info

        for _, value in ipairs(dropdown.values or {}) do
            info = UIDropDownMenu_CreateInfo()
            info.text = dropdown.labelForValue and dropdown.labelForValue(value) or tostring(value)
            info.value = value
            if isInstanceGroupEntry(value) then
                info.isTitle = true
                info.notCheckable = true
                info.disabled = true
                info.checked = false
                info.func = nil
            else
                info.checked = value == dropdown.currentValue
                info.func = function()
                    dropdown:SetCurrentValue(value)
                    onChange(value)
                end
            end
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    return dropdown
end

local function createSingleLineInput(frame, width, height)
	local editBox = CreateFrame("EditBox", nil, frame, "InputBoxTemplate")
	editBox:SetAutoFocus(false)
	editBox:SetWidth(width or 180)
	editBox:SetHeight(height or 24)
	editBox:SetFontObject(ChatFontNormal)
	editBox:SetTextInsets(6, 6, 0, 0)
	return editBox
end

local function createMultiLineInput(frame, width, height)
	local container = CreateFrame("Frame", nil, frame, "BackdropTemplate")
	container:SetSize(width or 620, height or 72)
	container:SetBackdrop({
		bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
		edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
		tile = true,
		tileSize = 16,
		edgeSize = 12,
		insets = { left = 3, right = 3, top = 3, bottom = 3 },
	})
	container:SetBackdropColor(0, 0, 0, 0.7)

	local editBox = CreateFrame("EditBox", nil, container)
	editBox:SetAutoFocus(false)
	editBox:SetMultiLine(true)
	editBox:SetFontObject(ChatFontNormal)
	editBox:SetWidth((width or 620) - 16)
	editBox:SetHeight((height or 72) - 16)
	editBox:SetPoint("TOPLEFT", container, "TOPLEFT", 8, -8)
	editBox:SetJustifyH("LEFT")
	editBox:SetJustifyV("TOP")
	editBox:SetTextInsets(0, 0, 0, 0)
	editBox:EnableMouse(true)
	editBox:SetScript("OnEscapePressed", function(self)
		self:ClearFocus()
	end)

	container.editBox = editBox
	return container, editBox
end


local _, addon = ...;

-- UI
TothysConf = {}
--local ACD = LibStub("MSA-AceConfigDialog-3.0")


-- Saved Variables
local defaultConfig = {
    ["Important"] = true,
    ["PriorityTargets"] = true,
    ["Defensives"] = true,
    ["Interrupts"] = true,
    ["Fluff"] = false,
    ["Advanced"] = true,
    ["Dodge"] = true,
    ["Personal"] = true,
    ["ShowFrame"] = "Show in separate frame",
    ["TargetTrigger"] = "Show targeted mob",
    ["DungeonToggle"] = true,
    ["RaidToggle"] = true,
    ["ShowMinimapButton"] = true,
    ["ShowNpcIDs"] = true,
    ["MythicPlusToggle"] = true,
    ["FrameWidth"] = 450,
    ["FrameHeight"] = 175,
    ["FontSize"] = 13,
    ["FrameOpacity"] = 0.55,
    ["LocaleChoice"] = "Auto",
    ["MinimapButtonAngle"] = 45,
    ["BrowserExpansionKey"] = "tbc",
    ["BrowserInstanceKey"] = "auchenai_crypts",
    ["BrowserNpcID"] = 18371,
    ["DungeonBrowserExpansionKey"] = "tbc",
    ["DungeonBrowserInstanceKey"] = "auchenai_crypts",
    ["NpcBrowserExpansionKey"] = "tbc",
    ["NpcBrowserInstanceKey"] = "auchenai_crypts",
    ["NpcBrowserNpcID"] = 18371,
    ["RoleFilters"] = {
        MYROLEONLY = false,
        TANK = true,
        HEALER = true,
        DAMAGE = true,
    },
    ["ClassFilters"] = {
        MYCLASSONLY = false,
        DRUID = true,
        HUNTER = true,
        MAGE = true,
        PALADIN = true,
        PRIEST = true,
        ROGUE = true,
        SHAMAN = true,
        WARRIOR = true,
        WARLOCK = true,
    },
}

local roleFilterKeys = {"MYROLEONLY", "TANK", "HEALER", "DAMAGE"}
local classFilterKeys = {"MYCLASSONLY", "DRUID", "HUNTER", "MAGE", "PALADIN", "PRIEST", "ROGUE", "SHAMAN", "WARRIOR", "WARLOCK"}

local function copyTable(source)
    local result = {}
    for key, value in pairs(source or {}) do
        if type(value) == "table" then
            result[key] = copyTable(value)
        else
            result[key] = value
        end
    end

    return result
end

local function applyConfigDefaults(config)
    for key, value in pairs(defaultConfig) do
        if config[key] == nil then
            if type(value) == "table" then
                config[key] = copyTable(value)
            else
                config[key] = value
            end
        end
    end

    if type(config.RoleFilters) ~= "table" then
        config.RoleFilters = copyTable(defaultConfig.RoleFilters)
    end
    if type(config.ClassFilters) ~= "table" then
        config.ClassFilters = copyTable(defaultConfig.ClassFilters)
    end

    for _, key in ipairs(roleFilterKeys) do
        if config.RoleFilters[key] == nil then
            config.RoleFilters[key] = defaultConfig.RoleFilters[key]
        end
    end

    for _, key in ipairs(classFilterKeys) do
        if config.ClassFilters[key] == nil then
            config.ClassFilters[key] = defaultConfig.ClassFilters[key]
        end
    end

    if config.RoleChoice then
        if config.RoleChoice == "Show all roles" then
            config.RoleFilters.MYROLEONLY = false
            config.RoleFilters.TANK = true
            config.RoleFilters.HEALER = true
            config.RoleFilters.DAMAGE = true
        else
            config.RoleFilters.MYROLEONLY = true
            config.RoleFilters.TANK = false
            config.RoleFilters.HEALER = false
            config.RoleFilters.DAMAGE = false
        end
        config.RoleChoice = nil
    end

    if config.ClassChoice then
        if config.ClassChoice == "Show all classes" then
            config.ClassFilters.MYCLASSONLY = false
            for _, key in ipairs(classFilterKeys) do
                if key ~= "MYCLASSONLY" then
                    config.ClassFilters[key] = true
                end
            end
        else
            config.ClassFilters.MYCLASSONLY = true
            for _, key in ipairs(classFilterKeys) do
                if key ~= "MYCLASSONLY" then
                    config.ClassFilters[key] = false
                end
            end
        end
        config.ClassChoice = nil
    end

    return config
end
function addon:registerConfigPanel()
	if addon.configPanelRegistered or not addon.configPanel then
		return
	end

	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		local category = Settings.RegisterCanvasLayoutCategory(addon.configPanel, addon.configPanel.name, addon.configPanel.name)
		if category then
			category.ID = category.ID or addon.configPanel.name
			Settings.RegisterAddOnCategory(category)
			addon.configCategory = category
			if addon.contentBrowserPanel and Settings.RegisterCanvasLayoutSubcategory then
				local subcategory = Settings.RegisterCanvasLayoutSubcategory(category, addon.contentBrowserPanel, addon.contentBrowserPanel.name, addon.contentBrowserPanel.name)
				if subcategory then
					subcategory.ID = subcategory.ID or addon.contentBrowserPanel.name
					Settings.RegisterAddOnCategory(subcategory)
					addon.contentBrowserCategory = subcategory
				end
			end
			if addon.npcBrowserPanel and Settings.RegisterCanvasLayoutSubcategory then
				local subcategory = Settings.RegisterCanvasLayoutSubcategory(category, addon.npcBrowserPanel, addon.npcBrowserPanel.name, addon.npcBrowserPanel.name)
				if subcategory then
					subcategory.ID = subcategory.ID or addon.npcBrowserPanel.name
					Settings.RegisterAddOnCategory(subcategory)
					addon.npcBrowserCategory = subcategory
				end
			end
			if addon.dungeonEditorPanel and Settings.RegisterCanvasLayoutSubcategory then
				local subcategory = Settings.RegisterCanvasLayoutSubcategory(category, addon.dungeonEditorPanel, addon.dungeonEditorPanel.name, addon.dungeonEditorPanel.name)
				if subcategory then
					subcategory.ID = subcategory.ID or addon.dungeonEditorPanel.name
					Settings.RegisterAddOnCategory(subcategory)
					addon.dungeonEditorCategory = subcategory
				end
			end
			if addon.editorPanel and Settings.RegisterCanvasLayoutSubcategory then
				local subcategory = Settings.RegisterCanvasLayoutSubcategory(category, addon.editorPanel, addon.editorPanel.name, addon.editorPanel.name)
				if subcategory then
					subcategory.ID = subcategory.ID or addon.editorPanel.name
					Settings.RegisterAddOnCategory(subcategory)
					addon.editorCategory = subcategory
				end
			end
			if addon.infoPanel and Settings.RegisterCanvasLayoutSubcategory then
				local subcategory = Settings.RegisterCanvasLayoutSubcategory(category, addon.infoPanel, addon.infoPanel.name, addon.infoPanel.name)
				if subcategory then
					subcategory.ID = subcategory.ID or addon.infoPanel.name
					Settings.RegisterAddOnCategory(subcategory)
					addon.infoCategory = subcategory
				end
			end
			addon.configPanelRegistered = true
			return
		end
	end

	if InterfaceOptions_AddCategory then
		InterfaceOptions_AddCategory(addon.configPanel)
		if addon.contentBrowserPanel then
			addon.contentBrowserPanel.parent = addon.configPanel.name
			InterfaceOptions_AddCategory(addon.contentBrowserPanel)
		end
		if addon.npcBrowserPanel then
			addon.npcBrowserPanel.parent = addon.configPanel.name
			InterfaceOptions_AddCategory(addon.npcBrowserPanel)
		end
		if addon.dungeonEditorPanel then
			addon.dungeonEditorPanel.parent = addon.configPanel.name
			InterfaceOptions_AddCategory(addon.dungeonEditorPanel)
		end
		if addon.editorPanel then
			addon.editorPanel.parent = addon.configPanel.name
			InterfaceOptions_AddCategory(addon.editorPanel)
		end
		if addon.infoPanel then
			addon.infoPanel.parent = addon.configPanel.name
			InterfaceOptions_AddCategory(addon.infoPanel)
		end
		addon.configPanelRegistered = true
	elseif InterfaceOptionsFrame_AddCategory then
		InterfaceOptionsFrame_AddCategory(addon.configPanel)
		if addon.contentBrowserPanel then
			addon.contentBrowserPanel.parent = addon.configPanel.name
			InterfaceOptionsFrame_AddCategory(addon.contentBrowserPanel)
		end
		if addon.npcBrowserPanel then
			addon.npcBrowserPanel.parent = addon.configPanel.name
			InterfaceOptionsFrame_AddCategory(addon.npcBrowserPanel)
		end
		if addon.dungeonEditorPanel then
			addon.dungeonEditorPanel.parent = addon.configPanel.name
			InterfaceOptionsFrame_AddCategory(addon.dungeonEditorPanel)
		end
		if addon.editorPanel then
			addon.editorPanel.parent = addon.configPanel.name
			InterfaceOptionsFrame_AddCategory(addon.editorPanel)
		end
		if addon.infoPanel then
			addon.infoPanel.parent = addon.configPanel.name
			InterfaceOptionsFrame_AddCategory(addon.infoPanel)
		end
		addon.configPanelRegistered = true
	end
end

TDTConfig = applyConfigDefaults(TDTConfig or QEConfig or {})
if type(TDTConfig.FontSize) ~= "number" then
    TDTConfig.FontSize = tonumber(TDTConfig.FontSize) or defaultConfig.FontSize
end
if TDTConfig.LocaleChoice ~= "Auto" and TDTConfig.LocaleChoice ~= "enUS" and TDTConfig.LocaleChoice ~= "deDE" then
    TDTConfig.LocaleChoice = defaultConfig.LocaleChoice
end

-- Create Checkboxes
local function createCheck(label, description, frame, onClick)
	local check = CreateFrame("CheckButton", "TDTCheck" .. label, frame, "InterfaceOptionsCheckButtonTemplate")
	check:SetScript("OnClick", function(self)
		onClick(self)
	end)
	
	getglobal(check:GetName() .. 'Text'):SetText(description)
	
	return check
	
end


local function createString(frame, text, font, size)
	local fontString = frame:CreateFontString()
	fontString:SetFont(font, size)
	fontString:SetText(text)
	fontString:SetWidth(215)
	fontString:SetJustifyH("LEFT")
	fontString:SetJustifyV("TOP")
	
	return fontString
end

local function updateTextSize(size)
	local p,_,_ = TDT_TipText:GetFont();
	--print("Resetting Font Size" .. TDTConfig.FontSize)
	TDT_TipText:SetFont(p, TDTConfig.FontSize, nil)
	if addon.refreshTipScroll then addon:refreshTipScroll() end

end

local function getConfigLocale()
    local preferredLocale = TDTConfig and TDTConfig.LocaleChoice or "Auto"
    if preferredLocale == "Auto" then
        preferredLocale = GetLocale() or "enUS"
    end

    if preferredLocale ~= "deDE" then
        preferredLocale = "enUS"
    end

    return preferredLocale
end

local function getBrowserLocaleString(key)
	local localeStrings = browserLocaleStrings[getConfigLocale()] or browserLocaleStrings.enUS
	return localeStrings[key] or browserLocaleStrings.enUS[key] or key
end

isInstanceGroupEntry = function(value)
	return type(value) == "string" and string.sub(value, 1, string.len(INSTANCE_GROUP_PREFIX)) == INSTANCE_GROUP_PREFIX
end

makeInstanceGroupEntry = function(labelKey)
	return INSTANCE_GROUP_PREFIX .. labelKey
end

getInstanceGroupLabel = function(value)
	if not isInstanceGroupEntry(value) then
		return value
	end

	return getBrowserLocaleString(string.sub(value, string.len(INSTANCE_GROUP_PREFIX) + 1)) or value
end

getFirstSelectableValue = function(values)
	for _, value in ipairs(values or {}) do
		if not isInstanceGroupEntry(value) then
			return value
		end
	end

	return nil
end

local function getLocalizedClassName(classKey)
    return getBrowserLocaleString("class_" .. string.lower(classKey or "")) or classKey
end

StaticPopupDialogs["TDT_CONFIRM_LOCALE_RELOAD"] = {
	text = "Reload UI?",
	button1 = "Reload",
	button2 = "Cancel",
	OnAccept = function(self)
		if self and self.data then
			TDTConfig.LocaleChoice = self.data
		end
		if ReloadUI then
			ReloadUI()
		end
	end,
	OnCancel = function(self)
		if self and self.data2 and self.data2.dropdown then
			self.data2.dropdown:SetCurrentValue(self.data2.previousValue)
		end
	end,
	timeout = 0,
	whileDead = 1,
	hideOnEscape = 1,
	preferredIndex = STATICPOPUP_NUMDIALOGS,
}

local function getOrderedKeys(entries)
    local keys = {}
    for key in pairs(entries or {}) do
        keys[#keys + 1] = key
    end

    table.sort(keys, function(left, right)
        local leftEntry = entries[left] or {}
        local rightEntry = entries[right] or {}
        local leftOrder = leftEntry.order or 9999
        local rightOrder = rightEntry.order or 9999

        if leftOrder == rightOrder then
            return tostring(left) < tostring(right)
        end

        return leftOrder < rightOrder
    end)

    return keys
end

local function getLocalizedLabel(labelData, fallback)
    if type(labelData) == "table" then
        local locale = getConfigLocale()
        return labelData[locale] or labelData.enUS or fallback
    end

    return labelData or fallback
end

local function getInstanceDetails(instanceKey)
    if addon.getMergedInstanceDetails then
        return addon:getMergedInstanceDetails(instanceKey)
    end
end

local function formatInstanceDetails(details)
    if not details then
        return getBrowserLocaleString("no_details")
    end

    local sections = {}

    if details.travel and details.travel ~= "" then
        sections[#sections + 1] = string.format("%s: %s", getBrowserLocaleString("travel"), details.travel)
    end
    if details.attunement and details.attunement ~= "" then
        sections[#sections + 1] = string.format("%s: %s", getBrowserLocaleString("attunement"), details.attunement)
    end
    if details.notes and details.notes ~= "" then
        sections[#sections + 1] = string.format("%s: %s", getBrowserLocaleString("extra_notes"), details.notes)
    end
    if details.lore and details.lore ~= "" then
        sections[#sections + 1] = string.format("%s: %s", getBrowserLocaleString("lore"), details.lore)
    end

    if #sections == 0 then
        return getBrowserLocaleString("no_details")
    end

    return table.concat(sections, "\n")
end

local function normalizeRawTips(rawTips)
    local normalizedTips = {}
    if not rawTips then
        return normalizedTips
    end

    local legacyTipCount = #rawTips
    for index, tip in ipairs(rawTips) do
        local tipType
        local tipText
        local tipWeight

        if #tip >= 4 and type(tip[2]) == "string" and type(tip[3]) == "string" then
            tipType = tip[2]
            tipText = tip[3]
            tipWeight = tonumber(tip[4]) or 0
        else
            tipType = tip[1]
            tipText = tip[2]
            tipWeight = (legacyTipCount - index + 1) * 10
        end

        normalizedTips[#normalizedTips + 1] = {
            type = tipType,
            text = tipText,
            weight = tipWeight,
            order = index,
        }
    end

    table.sort(normalizedTips, function(left, right)
        if left.weight == right.weight then
            return left.order < right.order
        end

        return left.weight > right.weight
    end)

    return normalizedTips
end

local function rgbToHex(r, g, b)
    return string.format("%02x%02x%02x", math.floor((r or 1) * 255), math.floor((g or 1) * 255), math.floor((b or 1) * 255))
end

local function formatTipTypeMarkup(tipType)
    local iconMarkup = ""
    local iconName = browserIconList[tipType or ""]
    if iconName then
        iconMarkup = string.format("|TInterface\\Icons\\%s:0|t ", iconName)
    end

    local color = browserTypeColors[tipType or ""]
    if color then
        return string.format("%s|cff%s[%s]|r", iconMarkup, rgbToHex(color[1], color[2], color[3]), tipType or "?")
    end

    return string.format("%s[%s]", iconMarkup, tipType or "?")
end

local function formatTipEntriesPreview(entries, maxLines)
    local previewLines = {}
    local allEntries = entries or {}
    local lineCount = maxLines and math.min(#allEntries, maxLines) or #allEntries

    for index = 1, lineCount do
        local tip = allEntries[index]
        previewLines[#previewLines + 1] = string.format("%s %s", formatTipTypeMarkup(tip.type), tip.text or "")
    end

    if maxLines and #allEntries > lineCount then
        previewLines[#previewLines + 1] = string.format("... %d more", #allEntries - lineCount)
    end

    if #previewLines == 0 then
        previewLines[#previewLines + 1] = "No entries found."
    end

    return table.concat(previewLines, "\n")
end

local function formatTipsPreview(rawTips, maxLines)
    return formatTipEntriesPreview(normalizeRawTips(rawTips), maxLines)
end

local function toDisplayTips(rawTips)
    local displayTips = {}
    local normalizedTips = normalizeRawTips(rawTips)

    for _, tip in ipairs(normalizedTips) do
        displayTips[#displayTips + 1] = {tip.type, tip.text}
    end

    return displayTips
end

local function mergedEntriesToDisplayTips(entries)
    local displayTips = {}
    for _, tip in ipairs(entries or {}) do
        displayTips[#displayTips + 1] = {tip.type, tip.text}
    end

    return displayTips
end

local function buildDetailLines(details)
    local lines = {}
    if not details then
        return lines
    end

    if details.travel and details.travel ~= "" then
        lines[#lines + 1] = string.format("%s: %s", getBrowserLocaleString("travel"), details.travel)
    end
    if details.attunement and details.attunement ~= "" then
        lines[#lines + 1] = string.format("%s: %s", getBrowserLocaleString("attunement"), details.attunement)
    end
    if details.notes and details.notes ~= "" then
        lines[#lines + 1] = string.format("%s: %s", getBrowserLocaleString("extra_notes"), details.notes)
    end
    if details.lore and details.lore ~= "" then
        lines[#lines + 1] = string.format("%s: %s", getBrowserLocaleString("lore"), details.lore)
    end

    return lines
end

local function sendBrowserLineToChat(message, channel)
    if not message or message == "" or not SendChatMessage then
        return
    end

    SendChatMessage(message, channel)
end

local function createBrowserShareRows(parent, count)
    local rows = {}

    for index = 1, count do
        local row = CreateFrame("Frame", nil, parent)
        row:SetSize(620, 34)

        row.text = createString(row, "", "Fonts\\FRIZQT__.TTF", 11)
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
        row.text:SetWidth(420)

        local buttons = {
            {"S", "SAY", 24},
            {"P", "PARTY", 24},
            {"G", "GUILD", 24},
            {"RA", "RAID", 28},
            {"RW", "RAID_WARNING", 28},
        }

        row.shareButtons = {}
        local previousButton
        for _, buttonInfo in ipairs(buttons) do
            local label, channel, width = buttonInfo[1], buttonInfo[2], buttonInfo[3]
            local button = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
            button:SetSize(width, 20)
            if previousButton then
                button:SetPoint("RIGHT", previousButton, "LEFT", -4, 0)
            else
                button:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 0)
            end
            button:SetText(label)
            button:SetScript("OnClick", function(self)
                sendBrowserLineToChat(self.message, self.channel)
            end)
            button.channel = channel
            row.shareButtons[#row.shareButtons + 1] = button
            previousButton = button
        end

        row:Hide()
        rows[index] = row
    end

    return rows
end

local function getExpansionKeys()
    return getOrderedKeys(addon.contentCatalog or {})
end

local function getExpansionData(expansionKey)
    if not addon.contentCatalog then
        return nil
    end

    return addon.contentCatalog[expansionKey]
end

local function getInstanceKeys(expansionKey)
    local expansionData = getExpansionData(expansionKey)
    if not expansionData then
        return {}
    end

    if expansionKey == "tbc" then
        local instances = expansionData.instances or {}
        local keys = {}
        local added = {}

        for _, group in ipairs(groupedTbcInstanceKeys) do
            local found = {}
            for _, instanceKey in ipairs(group.instances) do
                if instances[instanceKey] then
                    found[#found + 1] = instanceKey
                    added[instanceKey] = true
                end
            end
            if #found > 0 then
                keys[#keys + 1] = makeInstanceGroupEntry(group.label)
                for _, instanceKey in ipairs(found) do
                    keys[#keys + 1] = instanceKey
                end
            end
        end

        for _, instanceKey in ipairs(getOrderedKeys(instances)) do
            if not added[instanceKey] then
                keys[#keys + 1] = instanceKey
            end
        end

        return keys
    end

    return getOrderedKeys(expansionData.instances or {})
end

local function getInstanceData(expansionKey, instanceKey)
    if isInstanceGroupEntry(instanceKey) then
        return nil
    end

    local expansionData = getExpansionData(expansionKey)
    if not expansionData or not expansionData.instances then
        return nil
    end

    return expansionData.instances[instanceKey]
end

local function getNpcIDs(expansionKey, instanceKey)
    local instanceData = getInstanceData(expansionKey, instanceKey)
    if not instanceData or not instanceData.npcIDs then
        return {}
    end

    local npcIDs = {}
    for _, npcID in ipairs(instanceData.npcIDs) do
        npcIDs[#npcIDs + 1] = npcID
    end

    table.sort(npcIDs, function(left, right)
        return tonumber(left) < tonumber(right)
    end)

    table.insert(npcIDs, 1, NPC_NONE)
    return npcIDs
end

local function getNpcSortName(expansionKey, instanceKey, npcID)
    if npcID == NPC_NONE then
        return "---"
    end

    local localizedName = addon.getCatalogNpcName and addon:getCatalogNpcName(expansionKey, instanceKey, npcID)
    if localizedName and localizedName ~= "" then
        return localizedName
    end

    local rawTips = addon.getShippedNpcTipEntries and addon:getShippedNpcTipEntries(npcID)
    local commentName = getNpcCommentName(rawTips)
    if commentName and commentName ~= "" then
        return commentName
    end

    return tostring(npcID)
end

local function getNpcAlphaBucket(expansionKey, instanceKey, npcID)
    local sortName = getNpcSortName(expansionKey, instanceKey, npcID)
    local first = sortName:match("^%s*([A-Za-z])")
    if not first then
        return "s_z"
    end

    local upper = string.upper(first)
    if upper >= "A" and upper <= "I" then
        return "a_i"
    elseif upper >= "J" and upper <= "R" then
        return "j_r"
    end
    return "s_z"
end

local function getNpcIDsForSelector(expansionKey, instanceKey, selector)
    local allNpcIDs = getNpcIDs(expansionKey, instanceKey)
    if selector == "bosses" then
        local npcIDs = { NPC_NONE }
        local groups = addon.npcGroups and addon.npcGroups[instanceKey]
        for _, npcID in ipairs(allNpcIDs) do
            if npcID ~= NPC_NONE and groups and groups[npcID] == "boss" then
                npcIDs[#npcIDs + 1] = npcID
            end
        end
        table.sort(npcIDs, function(left, right)
            if left == NPC_NONE then
                return true
            end
            if right == NPC_NONE then
                return false
            end
            return getNpcSortName(expansionKey, instanceKey, left) < getNpcSortName(expansionKey, instanceKey, right)
        end)
        return npcIDs
    end

    if selector == "ids" then
        return allNpcIDs
    end

    local npcIDs = { NPC_NONE }
    for _, npcID in ipairs(allNpcIDs) do
        if npcID ~= NPC_NONE and getNpcAlphaBucket(expansionKey, instanceKey, npcID) == selector then
            npcIDs[#npcIDs + 1] = npcID
        end
    end

    table.sort(npcIDs, function(left, right)
        if left == NPC_NONE then
            return true
        end
        if right == NPC_NONE then
            return false
        end
        return getNpcSortName(expansionKey, instanceKey, left) < getNpcSortName(expansionKey, instanceKey, right)
    end)

    return npcIDs
end

local function getNpcCommentName(rawTips)
    return nil
end

local function shouldShowNpcIDs()
    return not TDTConfig or TDTConfig.ShowNpcIDs ~= false
end

local function getNpcBrowserLabel(expansionKey, instanceKey, npcID)
    if npcID == NPC_NONE then
        return "---"
    end

    local localizedName = addon.getCatalogNpcName and addon:getCatalogNpcName(expansionKey, instanceKey, npcID)

    if localizedName then
        if not shouldShowNpcIDs() then
            return localizedName
        end
        return string.format("%s (%d)", localizedName, npcID)
    end

    local rawTips = addon.getShippedNpcTipEntries and addon:getShippedNpcTipEntries(npcID)
    local commentName = getNpcCommentName(rawTips)
    if commentName then
        if not shouldShowNpcIDs() then
            return commentName
        end
        return string.format("%s (%d)", commentName, npcID)
    end

    return tostring(npcID)
end

local function getNpcDisplayName(expansionKey, instanceKey, npcID)
    if npcID == NPC_NONE then
        return nil
    end
    local browserLabel = getNpcBrowserLabel(expansionKey, instanceKey, npcID)
    return browserLabel:gsub("%s*%(%d+%)$", "")
end

local function createFilterCheck(name, description, frame, onClick)
    return createCheck(name, description, frame, onClick)
end

local function setupScrollablePanel(panel, prefix, contentHeight)
    local scrollFrame = CreateFrame("ScrollFrame", prefix .. "ScrollFrame", panel)
    scrollFrame:SetPoint("TOPLEFT", panel, "TOPLEFT", 0, -8)
    scrollFrame:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -28, -8)
    scrollFrame:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 0, 8)
    scrollFrame:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -28, 8)
    scrollFrame:EnableMouseWheel(true)

    local content = CreateFrame("Frame", prefix .. "ScrollChild", scrollFrame)
    content:SetWidth(700)
    content:SetHeight(contentHeight or 1200)
    scrollFrame:SetScrollChild(content)

    local scrollBar = CreateFrame("Slider", prefix .. "ScrollBar", panel, "UIPanelScrollBarTemplate")
    scrollBar:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -4, -24)
    scrollBar:SetPoint("BOTTOMRIGHT", panel, "BOTTOMRIGHT", -4, 24)
    scrollBar:SetMinMaxValues(0, 0)
    scrollBar:SetValueStep(24)
    scrollBar:SetValue(0)
    scrollBar:SetScript("OnValueChanged", function(self, value)
        scrollFrame:SetVerticalScroll(value)
    end)

    scrollFrame:SetScript("OnMouseWheel", function(self, delta)
        local currentValue = scrollBar:GetValue()
        local minValue, maxValue = scrollBar:GetMinMaxValues()
        local nextValue = currentValue - (delta * 36)
        if nextValue < minValue then nextValue = minValue end
        if nextValue > maxValue then nextValue = maxValue end
        scrollBar:SetValue(nextValue)
    end)

    panel.refreshScroll = function()
        local maxScroll = math.max((contentHeight or 1200) - scrollFrame:GetHeight(), 0)
        scrollBar:SetMinMaxValues(0, maxScroll)
        if maxScroll == 0 then
            scrollBar:SetValue(0)
            scrollBar:Hide()
        else
            if scrollBar:GetValue() > maxScroll then
                scrollBar:SetValue(maxScroll)
            end
            scrollBar:Show()
        end
    end

    panel:SetScript("OnShow", function(self)
        if self.refreshScroll then
            self:refreshScroll()
        end
    end)

    panel:HookScript("OnSizeChanged", function(self)
        if self.refreshScroll then
            self:refreshScroll()
        end
    end)

    return content
end


--[[
function createDropdown(frame, label, option1, option2, changingVar)

	local dd = CreateFrame("Frame", label, frame, "UIDropDownMenuTemplate")
	
	local function dd_OnClick(self, arg1, arg2, checked)
		UIDropDownMenu_SetText(dd, arg1)
		TDTConfig[changingVar] = arg1
		setEnabled() -- This just clears the addons frame.
		setDropdownEnabled() -- This shows / hides a second dropdown based on the current selection.
	end
	
	function ddMenu(frame, level, menuList)
		local info = UIDropDownMenu_CreateInfo()
		info.func = dd_OnClick
		info.text, info.arg1, info.checked = option1, option1, TDTConfig[changingVar] == option1
		UIDropDownMenu_AddButton(info)
		info.text, info.arg1, info.checked = option2, option2, TDTConfig[changingVar] == option2
		UIDropDownMenu_AddButton(info)
	
	end
		
	UIDropDownMenu_Initialize(dd, ddMenu)
	UIDropDownMenu_SetWidth(dd, 180, 0);
	
	return dd
end
]]--

-- Create Panels
local npcSelectorDefinitions = {
    { key = "bosses", localeKey = "bosses", selector = "bosses", suffix = "Bosses" },
    { key = "ids", localeKey = "npc_ids", selector = "ids", suffix = "Ids" },
    { key = "a_i", localeKey = "npcs_a_i", selector = "a_i", suffix = "Ai" },
    { key = "j_r", localeKey = "npcs_j_r", selector = "j_r", suffix = "Jr" },
    { key = "s_z", localeKey = "npcs_s_z", selector = "s_z", suffix = "Sz" },
}

-- The browser and tip editor share the same five NPC selectors, so keep their layout and syncing in one place.
local function createNpcSelectorControls(parent, prefix, state, topAnchor, headerFont, headerSize, onSelectionChanged)
    local controls = {
        headers = {},
        dropdowns = {},
    }

    local previousAnchor = topAnchor

    for _, definition in ipairs(npcSelectorDefinitions) do
        local header = createString(parent, getBrowserLocaleString(definition.localeKey), headerFont, headerSize)
        header:SetPoint("TOPLEFT", previousAnchor, "BOTTOMLEFT", 16, -18)

        local dropdown = createValueDropdown(parent, prefix .. definition.suffix, 240, function(value)
            state.npcID = value
            onSelectionChanged()
        end)
        dropdown:SetPoint("TOPLEFT", header, "BOTTOMLEFT", -16, -2)
        dropdown.labelForValue = function(value)
            return getNpcBrowserLabel(state.expansionKey, state.instanceKey, value)
        end

        controls.headers[definition.key] = header
        controls.dropdowns[definition.key] = dropdown
        previousAnchor = dropdown
    end

    controls.lastDropdown = previousAnchor
    return controls
end

local function refreshNpcSelectorTexts(controls)
    if not controls then
        return
    end

    for _, definition in ipairs(npcSelectorDefinitions) do
        controls.headers[definition.key]:SetText(getBrowserLocaleString(definition.localeKey))
    end
end

local function syncNpcSelectorControls(controls, state)
    if not controls then
        return
    end

    local selectedNpcID = state.npcID ~= NPC_NONE and state.npcID or nil

    for _, definition in ipairs(npcSelectorDefinitions) do
        controls.dropdowns[definition.key]:SetValues(getNpcIDsForSelector(state.expansionKey, state.instanceKey, definition.selector))
    end

    if selectedNpcID and addon.npcGroups and addon.npcGroups[state.instanceKey] and addon.npcGroups[state.instanceKey][selectedNpcID] == "boss" then
        controls.dropdowns.bosses:SetCurrentValue(selectedNpcID)
    else
        controls.dropdowns.bosses:SetCurrentValue(NPC_NONE)
    end

    controls.dropdowns.ids:SetCurrentValue(state.npcID)

    if selectedNpcID then
        local bucket = getNpcAlphaBucket(state.expansionKey, state.instanceKey, selectedNpcID)
        controls.dropdowns.a_i:SetCurrentValue(bucket == "a_i" and selectedNpcID or NPC_NONE)
        controls.dropdowns.j_r:SetCurrentValue(bucket == "j_r" and selectedNpcID or NPC_NONE)
        controls.dropdowns.s_z:SetCurrentValue(bucket == "s_z" and selectedNpcID or NPC_NONE)
    else
        controls.dropdowns.a_i:SetCurrentValue(NPC_NONE)
        controls.dropdowns.j_r:SetCurrentValue(NPC_NONE)
        controls.dropdowns.s_z:SetCurrentValue(NPC_NONE)
    end
end

local function ensureExpansionInstanceSelection(state, options)
    options = options or {}

    local expansionKeys = getExpansionKeys()
    if #expansionKeys == 0 then
        state.expansionKey = nil
        state.instanceKey = nil
        if options.includeNpc then
            state.npcID = nil
        end
        return
    end

    local hasExpansion = false
    for _, key in ipairs(expansionKeys) do
        if key == state.expansionKey then
            hasExpansion = true
            break
        end
    end
    if not hasExpansion then
        state.expansionKey = expansionKeys[1]
    end

    local instanceKeys = getInstanceKeys(state.expansionKey)
    local hasInstance = false
    for _, key in ipairs(instanceKeys) do
        if key == state.instanceKey then
            hasInstance = true
            break
        end
    end
    if not hasInstance then
        state.instanceKey = getFirstSelectableValue(instanceKeys)
    end

    if options.includeNpc then
        local npcIDs = getNpcIDs(state.expansionKey, state.instanceKey)
        local hasNpc = false
        for _, npcID in ipairs(npcIDs) do
            if npcID == state.npcID then
                hasNpc = true
                break
            end
        end
        if not hasNpc then
            state.npcID = NPC_NONE
        end
    end

    if options.onPersist then
        options.onPersist(state)
    end
end

local function syncExpansionInstanceControls(state, expansionButton, instanceDropdown)
    expansionButton:SetValues(getExpansionKeys())
    expansionButton:SetCurrentValue(state.expansionKey)
    instanceDropdown:SetValues(getInstanceKeys(state.expansionKey))
    instanceDropdown:SetCurrentValue(state.instanceKey)
end

local function createContentBrowserMenu()
    addon.contentBrowserPanel = CreateFrame("Frame", "TothysDungeonTipsDungeonBrowser", UIParent)
    addon.contentBrowserPanel.name = getBrowserLocaleString("content_browser_page")
    addon.contentBrowserPanel.okay = function(self) return end
    addon.contentBrowserPanel.cancel = function(self) return end
    local browserContent = setupScrollablePanel(addon.contentBrowserPanel, "TDTDungeonBrowser", 1200)

    local headerFont = "Fonts\\MORPHEUS.ttf"
    local headerSize = 16
    local browserState = {
        expansionKey = TDTConfig.DungeonBrowserExpansionKey or TDTConfig.BrowserExpansionKey,
        instanceKey = TDTConfig.DungeonBrowserInstanceKey or TDTConfig.BrowserInstanceKey,
    }
    local updateBrowserUI

    local title = browserContent:CreateFontString()
    title:SetPoint("TOPLEFT", 10, -10)
    title:SetFont("Fonts\\MORPHEUS.ttf", 22, "OUTLINE")
    title:SetTextColor(0.9, 0.68, 0.22, 1)

    local subtitle = createString(browserContent, "", "Fonts\\FRIZQT__.TTF", 11)
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    subtitle:SetWidth(540)

    local expansionFS = createString(browserContent, "", headerFont, headerSize)
    expansionFS:SetPoint("TOPLEFT", subtitle, "BOTTOMLEFT", 0, -20)

    local expansionButton = createCycleButton(browserContent, "DungeonBrowserExpansion", getExpansionKeys(), function(value)
        browserState.expansionKey = value
        browserState.instanceKey = nil
        updateBrowserUI()
    end)
    expansionButton:SetPoint("TOPLEFT", expansionFS, "BOTTOMLEFT", 0, -8)
    expansionButton.labelForValue = function(value)
        local expansionData = getExpansionData(value)
        return getLocalizedLabel(expansionData and expansionData.name, value)
    end

    local instanceFS = createString(browserContent, "", headerFont, headerSize)
    instanceFS:SetPoint("TOPLEFT", expansionButton, "BOTTOMLEFT", 0, -24)

    local instanceDropdown = createValueDropdown(browserContent, "DungeonBrowserInstance", 220, function(value)
        browserState.instanceKey = value
        updateBrowserUI()
    end)
    instanceDropdown:SetPoint("TOPLEFT", instanceFS, "BOTTOMLEFT", -16, -2)
    instanceDropdown.labelForValue = function(value)
        if isInstanceGroupEntry(value) then
            return getInstanceGroupLabel(value)
        end
        local instanceData = getInstanceData(browserState.expansionKey, value)
        if not instanceData then
            return value or "-"
        end
        return string.format("%s (%s)", getLocalizedLabel(instanceData.name, value), instanceData.type or "Unknown")
    end

    local selectionSummary = createString(browserContent, "", "Fonts\\FRIZQT__.TTF", 11)
    selectionSummary:SetPoint("TOPLEFT", instanceDropdown, "BOTTOMLEFT", 16, -18)
    selectionSummary:SetWidth(620)

    local instancePreviewFS = createString(browserContent, "", headerFont, headerSize)
    instancePreviewFS:SetPoint("TOPLEFT", selectionSummary, "BOTTOMLEFT", 0, -18)
    local instanceTipRows = createBrowserShareRows(browserContent, 20)

    local instanceDetailsFS = createString(browserContent, "", headerFont, headerSize)
    local instanceDetailRows = createBrowserShareRows(browserContent, 8)

    local function setBrowserRows(rows, startAnchor, lines)
        local lastAnchor = startAnchor
        for _, row in ipairs(rows) do
            row:Hide()
        end
        if not lines or #lines == 0 then
            return startAnchor
        end
        for index, line in ipairs(lines) do
            local row = rows[index]
            if not row then
                break
            end
            row:ClearAllPoints()
            if index == 1 then
                row:SetPoint("TOPLEFT", startAnchor, "BOTTOMLEFT", 0, -6)
            else
                row:SetPoint("TOPLEFT", rows[index - 1], "BOTTOMLEFT", 0, -6)
            end
            row.text:SetText(line.display)
            for _, button in ipairs(row.shareButtons or {}) do
                button.message = line.message
            end
            row:Show()
            lastAnchor = row
        end
        return lastAnchor
    end

    local function refreshBrowserTexts()
        addon.contentBrowserPanel.name = getBrowserLocaleString("content_browser_page")
        title:SetText(getBrowserLocaleString("content_browser_title"))
        subtitle:SetText(getBrowserLocaleString("content_browser_subtitle"))
        expansionFS:SetText(getBrowserLocaleString("expansion"))
        instanceFS:SetText(getBrowserLocaleString("dungeon_or_raid"))
        instancePreviewFS:SetText(getBrowserLocaleString("dungeon_info"))
        instanceDetailsFS:SetText(getBrowserLocaleString("additional_details"))
    end

    updateBrowserUI = function()
        ensureExpansionInstanceSelection(browserState, {
            onPersist = function(state)
                TDTConfig.DungeonBrowserExpansionKey = state.expansionKey
                TDTConfig.DungeonBrowserInstanceKey = state.instanceKey
            end,
        })
        syncExpansionInstanceControls(browserState, expansionButton, instanceDropdown)

        local expansionData = getExpansionData(browserState.expansionKey)
        local instanceData = getInstanceData(browserState.expansionKey, browserState.instanceKey)
        local expansionLabel = getLocalizedLabel(expansionData and expansionData.name, browserState.expansionKey or "-")
        local instanceLabel = getLocalizedLabel(instanceData and instanceData.name, browserState.instanceKey or "-")
        local instanceType = instanceData and instanceData.type or "Unknown"
        local mergedInstanceEntries = addon:getMergedInstanceTipEntries(browserState.instanceKey) or {}
        selectionSummary:SetText(string.format(getBrowserLocaleString("selected_instance"), expansionLabel, string.format("%s (%s)", instanceLabel, instanceType)))

        local instanceLines = {}
        for _, tip in ipairs(mergedInstanceEntries) do
            instanceLines[#instanceLines + 1] = {
                display = string.format("%s %s", formatTipTypeMarkup(tip.type), tip.text or ""),
                message = string.format("[%s] %s", tip.type or "?", tip.text or ""),
            }
        end
        if #instanceLines == 0 then
            instanceLines[#instanceLines + 1] = {
                display = getBrowserLocaleString("no_dungeon_tips"),
                message = getBrowserLocaleString("no_dungeon_tips"),
            }
        end
        local detailLines = {}
        for _, line in ipairs(buildDetailLines(getInstanceDetails(browserState.instanceKey))) do
            detailLines[#detailLines + 1] = { display = line, message = line }
        end
        if #detailLines == 0 then
            detailLines[#detailLines + 1] = {
                display = getBrowserLocaleString("no_details"),
                message = getBrowserLocaleString("no_details"),
            }
        end

        local lastInstanceAnchor = setBrowserRows(instanceTipRows, instancePreviewFS, instanceLines)
        instanceDetailsFS:ClearAllPoints()
        instanceDetailsFS:SetPoint("TOPLEFT", lastInstanceAnchor, "BOTTOMLEFT", 0, -18)
        setBrowserRows(instanceDetailRows, instanceDetailsFS, detailLines)
        if addon.showBrowserSelectionInFrame then
            addon:showBrowserSelectionInFrame(
                getLocalizedLabel(instanceData and instanceData.name, browserState.instanceKey or "-"),
                nil,
                nil,
                mergedEntriesToDisplayTips(mergedInstanceEntries),
                nil,
                browserState.instanceKey,
                browserState.expansionKey
            )
        end
        if addon.contentBrowserPanel.refreshScroll then addon.contentBrowserPanel:refreshScroll() end
    end

    addon.contentBrowserPanel:RegisterEvent("ADDON_LOADED")
    addon.contentBrowserPanel:SetScript("OnEvent", function(self, event, arg1)
        if event == "ADDON_LOADED" and arg1 == "Tothys-Dungeon-Tips-TBC" then
            TDTConfig = applyConfigDefaults(TDTConfig)
            browserState.expansionKey = TDTConfig.DungeonBrowserExpansionKey or TDTConfig.BrowserExpansionKey
            browserState.instanceKey = TDTConfig.DungeonBrowserInstanceKey or TDTConfig.BrowserInstanceKey
            refreshBrowserTexts()
            updateBrowserUI()
            if self.refreshScroll then self:refreshScroll() end
        end
    end)
    addon.contentBrowserPanel:HookScript("OnShow", function()
        refreshBrowserTexts()
        updateBrowserUI()
    end)
    refreshBrowserTexts()
    updateBrowserUI()
end

local function createNpcBrowserMenu()
    addon.npcBrowserPanel = CreateFrame("Frame", "TothysDungeonTipsNpcBrowser", UIParent)
    addon.npcBrowserPanel.name = getBrowserLocaleString("npc_browser_page")
    addon.npcBrowserPanel.okay = function(self) return end
    addon.npcBrowserPanel.cancel = function(self) return end
    local browserContent = setupScrollablePanel(addon.npcBrowserPanel, "TDTNpcBrowser", 1500)

    local headerFont = "Fonts\\MORPHEUS.ttf"
    local headerSize = 16
    local browserState = {
        expansionKey = TDTConfig.NpcBrowserExpansionKey or TDTConfig.BrowserExpansionKey,
        instanceKey = TDTConfig.NpcBrowserInstanceKey or TDTConfig.BrowserInstanceKey,
        npcID = TDTConfig.NpcBrowserNpcID or TDTConfig.BrowserNpcID,
    }
    local updateNpcBrowserUI

    local title = browserContent:CreateFontString()
    title:SetPoint("TOPLEFT", 10, -10)
    title:SetFont("Fonts\\MORPHEUS.ttf", 22, "OUTLINE")
    title:SetTextColor(0.9, 0.68, 0.22, 1)

    local subtitle = createString(browserContent, "", "Fonts\\FRIZQT__.TTF", 11)
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    subtitle:SetWidth(620)

    local expansionFS = createString(browserContent, "", headerFont, headerSize)
    expansionFS:SetPoint("TOPLEFT", subtitle, "BOTTOMLEFT", 0, -20)

    local expansionButton = createCycleButton(browserContent, "NpcBrowserExpansion", getExpansionKeys(), function(value)
        browserState.expansionKey = value
        browserState.instanceKey = nil
        browserState.npcID = nil
        updateNpcBrowserUI()
    end)
    expansionButton:SetPoint("TOPLEFT", expansionFS, "BOTTOMLEFT", 0, -8)
    expansionButton.labelForValue = function(value)
        local expansionData = getExpansionData(value)
        return getLocalizedLabel(expansionData and expansionData.name, value)
    end

    local instanceFS = createString(browserContent, "", headerFont, headerSize)
    instanceFS:SetPoint("TOPLEFT", expansionButton, "BOTTOMLEFT", 0, -24)

    local instanceDropdown = createValueDropdown(browserContent, "NpcBrowserInstance", 220, function(value)
        browserState.instanceKey = value
        browserState.npcID = nil
        updateNpcBrowserUI()
    end)
    instanceDropdown:SetPoint("TOPLEFT", instanceFS, "BOTTOMLEFT", -16, -2)
    instanceDropdown.labelForValue = function(value)
        if isInstanceGroupEntry(value) then
            return getInstanceGroupLabel(value)
        end
        local instanceData = getInstanceData(browserState.expansionKey, value)
        if not instanceData then
            return value or "-"
        end
        return string.format("%s (%s)", getLocalizedLabel(instanceData.name, value), instanceData.type or "Unknown")
    end

    local npcSelectors = createNpcSelectorControls(
        browserContent,
        "NpcBrowserNpc",
        browserState,
        instanceDropdown,
        headerFont,
        headerSize,
        function() updateNpcBrowserUI() end
    )

    local selectionSummary = createString(browserContent, "", "Fonts\\FRIZQT__.TTF", 11)
    selectionSummary:SetPoint("TOPLEFT", npcSelectors.lastDropdown, "BOTTOMLEFT", 16, -18)
    selectionSummary:SetWidth(620)

    local tabSelection = CreateFrame("Button", "TDTNpcBrowserSelectionTab", browserContent, "UIPanelButtonTemplate")
    tabSelection:SetSize(110, 24)
    tabSelection:SetPoint("TOPLEFT", selectionSummary, "BOTTOMLEFT", 0, -16)

    local tabAbilities = CreateFrame("Button", "TDTNpcBrowserAbilitiesTab", browserContent, "UIPanelButtonTemplate")
    tabAbilities:SetSize(110, 24)
    tabAbilities:SetPoint("LEFT", tabSelection, "RIGHT", 8, 0)

    local selectionFrame = CreateFrame("Frame", nil, browserContent)
    selectionFrame:SetPoint("TOPLEFT", tabSelection, "BOTTOMLEFT", 0, -12)
    selectionFrame:SetSize(650, 950)

    local abilitiesFrame = CreateFrame("Frame", nil, browserContent)
    abilitiesFrame:SetPoint("TOPLEFT", tabSelection, "BOTTOMLEFT", 0, -12)
    abilitiesFrame:SetSize(650, 950)

    local npcPreviewFS = createString(selectionFrame, getBrowserLocaleString("npc_tips"), headerFont, headerSize)
    npcPreviewFS:SetPoint("TOPLEFT", 0, 0)
    local npcHeadingRow = createBrowserShareRows(selectionFrame, 1)[1]
    local npcTipRows = createBrowserShareRows(selectionFrame, 24)

    local abilitiesHeader = createString(abilitiesFrame, getBrowserLocaleString("npc_browser_tab_abilities"), headerFont, headerSize)
    abilitiesHeader:SetPoint("TOPLEFT", 0, 0)
    local abilitiesText = createString(abilitiesFrame, "", "Fonts\\FRIZQT__.TTF", 11)
    abilitiesText:SetPoint("TOPLEFT", abilitiesHeader, "BOTTOMLEFT", 0, -8)
    abilitiesText:SetWidth(620)

    local activeTab = "selection"
    local function updateNpcBrowserTabs()
        local selectionActive = activeTab == "selection"
        tabSelection:SetEnabled(not selectionActive)
        tabAbilities:SetEnabled(selectionActive)
        selectionFrame:SetShown(selectionActive)
        abilitiesFrame:SetShown(not selectionActive)
    end

    local function setBrowserRows(rows, startAnchor, lines)
        local lastAnchor = startAnchor
        for _, row in ipairs(rows) do
            row:Hide()
        end
        if not lines or #lines == 0 then
            return startAnchor
        end
        for index, line in ipairs(lines) do
            local row = rows[index]
            if not row then
                break
            end
            row:ClearAllPoints()
            if index == 1 then
                row:SetPoint("TOPLEFT", startAnchor, "BOTTOMLEFT", 0, -6)
            else
                row:SetPoint("TOPLEFT", rows[index - 1], "BOTTOMLEFT", 0, -6)
            end
            row.text:SetText(line.display)
            for _, button in ipairs(row.shareButtons or {}) do
                button.message = line.message
            end
            row:Show()
            lastAnchor = row
        end
        return lastAnchor
    end

    local function refreshNpcBrowserTexts()
        addon.npcBrowserPanel.name = getBrowserLocaleString("npc_browser_page")
        title:SetText(getBrowserLocaleString("npc_browser_title"))
        subtitle:SetText(getBrowserLocaleString("npc_browser_subtitle"))
        expansionFS:SetText(getBrowserLocaleString("expansion"))
        instanceFS:SetText(getBrowserLocaleString("dungeon_or_raid"))
        refreshNpcSelectorTexts(npcSelectors)
        tabSelection:SetText(getBrowserLocaleString("npc_browser_tab_selection"))
        tabAbilities:SetText(getBrowserLocaleString("npc_browser_tab_abilities"))
        npcPreviewFS:SetText(getBrowserLocaleString("npc_tips"))
        abilitiesHeader:SetText(getBrowserLocaleString("npc_browser_tab_abilities"))
        abilitiesText:SetText(getBrowserLocaleString("npc_browser_abilities_placeholder"))
    end

    updateNpcBrowserUI = function()
        ensureExpansionInstanceSelection(browserState, {
            includeNpc = true,
            onPersist = function(state)
                TDTConfig.NpcBrowserExpansionKey = state.expansionKey
                TDTConfig.NpcBrowserInstanceKey = state.instanceKey
                TDTConfig.NpcBrowserNpcID = state.npcID
            end,
        })
        syncExpansionInstanceControls(browserState, expansionButton, instanceDropdown)
        syncNpcSelectorControls(npcSelectors, browserState)

        local expansionData = getExpansionData(browserState.expansionKey)
        local instanceData = getInstanceData(browserState.expansionKey, browserState.instanceKey)
        local expansionLabel = getLocalizedLabel(expansionData and expansionData.name, browserState.expansionKey or "-")
        local instanceLabel = getLocalizedLabel(instanceData and instanceData.name, browserState.instanceKey or "-")
        local selectedNpcID = browserState.npcID ~= NPC_NONE and browserState.npcID or nil
        local npcLabel = browserState.npcID and getNpcBrowserLabel(browserState.expansionKey, browserState.instanceKey, browserState.npcID) or "-"
        local npcDisplayName = selectedNpcID and getNpcDisplayName(browserState.expansionKey, browserState.instanceKey, selectedNpcID) or nil
        local mergedNpcEntries = (selectedNpcID and addon:getMergedNpcTipEntries(selectedNpcID)) or {}
        selectionSummary:SetText(string.format(getBrowserLocaleString("selected_npc_path"), expansionLabel, instanceLabel, npcLabel))

        npcHeadingRow:Hide()
        for _, row in ipairs(npcTipRows) do
            row:Hide()
        end

        local npcLines = {}
        for _, tip in ipairs(mergedNpcEntries) do
            npcLines[#npcLines + 1] = {
                display = string.format("%s %s", formatTipTypeMarkup(tip.type), tip.text or ""),
                message = string.format("[%s] %s", tip.type or "?", tip.text or ""),
            }
        end

        if selectedNpcID and npcDisplayName then
            npcHeadingRow:SetPoint("TOPLEFT", npcPreviewFS, "BOTTOMLEFT", 0, -6)
            npcHeadingRow.text:SetText(string.format("--- %s ---", npcDisplayName))
            for _, button in ipairs(npcHeadingRow.shareButtons or {}) do
                button.message = string.format("--- %s ---", npcDisplayName)
            end
            npcHeadingRow:Show()
            setBrowserRows(npcTipRows, npcHeadingRow, npcLines)
        else
            setBrowserRows(npcTipRows, npcPreviewFS, {
                {
                    display = getBrowserLocaleString("select_npc_to_view"),
                    message = getBrowserLocaleString("select_npc_to_view"),
                }
            })
        end

        abilitiesText:SetText(getBrowserLocaleString("npc_browser_abilities_placeholder"))
        updateNpcBrowserTabs()
        if addon.showBrowserSelectionInFrame then
            addon:showBrowserSelectionInFrame(
                getLocalizedLabel(instanceData and instanceData.name, browserState.instanceKey or "-"),
                npcDisplayName,
                selectedNpcID,
                nil,
                mergedEntriesToDisplayTips(mergedNpcEntries),
                browserState.instanceKey,
                browserState.expansionKey
            )
        end
        if addon.npcBrowserPanel.refreshScroll then addon.npcBrowserPanel:refreshScroll() end
    end

    tabSelection:SetScript("OnClick", function()
        activeTab = "selection"
        updateNpcBrowserTabs()
    end)
    tabAbilities:SetScript("OnClick", function()
        activeTab = "abilities"
        updateNpcBrowserTabs()
    end)

    addon.npcBrowserPanel:RegisterEvent("ADDON_LOADED")
    addon.npcBrowserPanel:SetScript("OnEvent", function(self, event, arg1)
        if event == "ADDON_LOADED" and arg1 == "Tothys-Dungeon-Tips-TBC" then
            TDTConfig = applyConfigDefaults(TDTConfig)
            browserState.expansionKey = TDTConfig.NpcBrowserExpansionKey or TDTConfig.BrowserExpansionKey
            browserState.instanceKey = TDTConfig.NpcBrowserInstanceKey or TDTConfig.BrowserInstanceKey
            browserState.npcID = TDTConfig.NpcBrowserNpcID or TDTConfig.BrowserNpcID
            refreshNpcBrowserTexts()
            updateNpcBrowserUI()
            if self.refreshScroll then self:refreshScroll() end
        end
    end)
    addon.npcBrowserPanel:HookScript("OnShow", function()
        refreshNpcBrowserTexts()
        updateNpcBrowserUI()
    end)
    refreshNpcBrowserTexts()
    updateNpcBrowserUI()
end

local function createEditorMenu()
    addon.editorPanel = CreateFrame("Frame", "TothysDungeonTipsEditor", UIParent)
    addon.editorPanel.name = getBrowserLocaleString("editor_page")
    addon.editorPanel.okay = function(self) return end
    addon.editorPanel.cancel = function(self) return end
    local editorContent = setupScrollablePanel(addon.editorPanel, "TDTEditor", 1650)

    local headerFont = "Fonts\\MORPHEUS.ttf"
    local headerSize = 16

    local title = editorContent:CreateFontString()
    title:SetPoint("TOPLEFT", 10, -10)
    title:SetFont("Fonts\\MORPHEUS.ttf", 22, "OUTLINE")
    title:SetTextColor(0.9, 0.68, 0.22, 1)
    title:SetText(getBrowserLocaleString("editor_title"))

    local subtitle = createString(editorContent, getBrowserLocaleString("editor_subtitle"), "Fonts\\FRIZQT__.TTF", 11)
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    subtitle:SetWidth(620)

    local expansionFS = createString(editorContent, getBrowserLocaleString("expansion"), headerFont, headerSize)
    expansionFS:SetPoint("TOPLEFT", subtitle, "BOTTOMLEFT", 0, -20)

    local editorState = {
        expansionKey = TDTConfig.BrowserExpansionKey,
        instanceKey = TDTConfig.BrowserInstanceKey,
        npcID = TDTConfig.BrowserNpcID,
    }

    local expansionButton
    local instanceDropdown
    local selectionSummary
    local npcPreview
    local addTipTypeDropdown
    local addTipWeightEdit
    local addTipTextBox
    local addTipStatus
    local personalTipsHeader
    local personalTipRows = {}
    local baseTipsHeader
    local baseTipRows = {}
    local editingTipID = nil
    local editingBaseTipID = nil
    local instanceFS
    local editorNpcSelectors
    local npcPreviewFS
    local addTipHeader
    local addTipTypeLabel
    local addTipWeightLabel
    local addTipTextLabel
    local saveTipButton
    local cancelEditButton

    local function refreshTipEditorTexts()
        addon.editorPanel.name = getBrowserLocaleString("editor_page")
        title:SetText(getBrowserLocaleString("editor_title"))
        subtitle:SetText(getBrowserLocaleString("editor_subtitle"))
        expansionFS:SetText(getBrowserLocaleString("expansion"))
        instanceFS:SetText(getBrowserLocaleString("dungeon_or_raid"))
        refreshNpcSelectorTexts(editorNpcSelectors)
        npcPreviewFS:SetText(getBrowserLocaleString("npc_tips"))
        addTipHeader:SetText(getBrowserLocaleString("add_npc_tip"))
        addTipTypeLabel:SetText(getBrowserLocaleString("tip_type"))
        addTipWeightLabel:SetText(getBrowserLocaleString("tip_weight"))
        addTipTextLabel:SetText(getBrowserLocaleString("tip_text"))
        saveTipButton:SetText(editingBaseTipID and getBrowserLocaleString("update_base_tip") or editingTipID and getBrowserLocaleString("update_tip") or getBrowserLocaleString("save_tip"))
        cancelEditButton:SetText(getBrowserLocaleString("cancel_edit"))
        personalTipsHeader:SetText(getBrowserLocaleString("personal_tips"))
        baseTipsHeader:SetText(getBrowserLocaleString("base_tips"))
        for _, row in ipairs(personalTipRows) do
            row.edit:SetText(getBrowserLocaleString("edit"))
            row.delete:SetText(getBrowserLocaleString("delete"))
        end
        for _, row in ipairs(baseTipRows) do
            row.reset:SetText(getBrowserLocaleString("reset"))
            row.edit:SetText(getBrowserLocaleString("edit_base"))
        end
    end

    local function setTipTypeDropdownInteractive(enabled)
        local alpha = enabled and 1 or 0.5
        addTipTypeDropdown:SetAlpha(alpha)
        local button = _G[addTipTypeDropdown:GetName() .. "Button"]
        if button then
            button:SetEnabled(enabled)
            button:SetAlpha(alpha)
        end
    end

    local function anchorBaseTipsHeader()
        local anchor = addTipStatus
        local offset = -22

        for index = #personalTipRows, 1, -1 do
            if personalTipRows[index]:IsShown() then
                anchor = personalTipRows[index]
                offset = -14
                break
            end
        end

        baseTipsHeader:ClearAllPoints()
        baseTipsHeader:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, offset)
    end

    local function ensureEditorSelection()
        ensureExpansionInstanceSelection(editorState, {
            includeNpc = true,
        })
    end

    local function updateEditorUI()
        ensureEditorSelection()
        syncExpansionInstanceControls(editorState, expansionButton, instanceDropdown)
        local expansionData = getExpansionData(editorState.expansionKey)
        local instanceData = getInstanceData(editorState.expansionKey, editorState.instanceKey)
        local expansionLabel = getLocalizedLabel(expansionData and expansionData.name, editorState.expansionKey or "-")
        local instanceLabel = getLocalizedLabel(instanceData and instanceData.name, editorState.instanceKey or "-")
        local selectedNpcID = editorState.npcID ~= NPC_NONE and editorState.npcID or nil
        syncNpcSelectorControls(editorNpcSelectors, editorState)
        local npcLabel = editorState.npcID and getNpcBrowserLabel(editorState.expansionKey, editorState.instanceKey, editorState.npcID) or "-"
        local mergedNpcEntries = selectedNpcID and (addon.getMergedNpcTipEntries and addon:getMergedNpcTipEntries(selectedNpcID) or {}) or nil
        local personalTips = selectedNpcID and (addon.getNpcUserAdditions and addon:getNpcUserAdditions(selectedNpcID) or {}) or {}
        local baseTips = selectedNpcID and (addon.getNpcBaseTipsForEditor and addon:getNpcBaseTipsForEditor(selectedNpcID) or {}) or {}

        selectionSummary:SetText(string.format(getBrowserLocaleString("selected_npc_path"), expansionLabel, instanceLabel, npcLabel))
        npcPreview:SetText(formatTipEntriesPreview(mergedNpcEntries))

        for _, row in ipairs(personalTipRows) do
            row:Hide()
        end
        for _, row in ipairs(baseTipRows) do
            row:Hide()
        end

        if #personalTips == 0 then
            if personalTipRows[1] then
                personalTipRows[1].text:SetText(getBrowserLocaleString("no_personal_tips"))
                personalTipRows[1].toggle:Hide()
                personalTipRows[1].edit:Hide()
                personalTipRows[1].delete:Hide()
                personalTipRows[1]:Show()
            end
        else
            for index, tip in ipairs(personalTips) do
                local row = personalTipRows[index]
                if row then
                    local hiddenLabel = tip.hidden and (" (" .. getBrowserLocaleString("hidden_tip") .. ")") or ""
                    row.text:SetText(string.format("[%s] %s (%d)%s\n%s", tip.type or "?", tip.id or "?", tip.weight or 0, hiddenLabel, tip.text or ""))
                    row.edit.tipID = tip.id
                    row.toggle:SetText(tip.hidden and getBrowserLocaleString("unhide") or getBrowserLocaleString("hide"))
                    row.toggle.tipID = tip.id
                    row.delete.tipID = tip.id
                    row.edit:Show()
                    row.toggle:Show()
                    row.delete:Show()
                    row:Show()
                end
            end
        end

        anchorBaseTipsHeader()

        if #baseTips == 0 then
            if baseTipRows[1] then
                baseTipRows[1].text:SetText(getBrowserLocaleString("no_base_tips"))
                baseTipRows[1].edit:Hide()
                baseTipRows[1].toggle:Hide()
                baseTipRows[1].reset:Hide()
                baseTipRows[1]:Show()
            end
        else
            for index, tip in ipairs(baseTips) do
                local row = baseTipRows[index]
                if row then
                    local statusBits = {}
                    if tip.hidden then
                        statusBits[#statusBits + 1] = getBrowserLocaleString("hidden_tip")
                    end
                    if tip.overridden then
                        statusBits[#statusBits + 1] = getBrowserLocaleString("overridden_tip")
                    end
                    if not tip.canModify then
                        statusBits[#statusBits + 1] = getBrowserLocaleString("legacy_tip")
                    end
                    local statusLabel = #statusBits > 0 and (" (" .. table.concat(statusBits, ", ") .. ")") or ""
                    local displayText
                    local typeMarkup = formatTipTypeMarkup(tip.type)
                    if tip.overridden and tip.overrideText then
                        local overrideWeight = tip.overrideWeight ~= nil and tip.overrideWeight or tip.weight or 0
                        displayText = string.format(
                            "%s %s (%d)%s\nOverride: %s\nOriginal (%d): %s",
                            typeMarkup,
                            tip.id or "-",
                            overrideWeight,
                            statusLabel,
                            tip.overrideText or "",
                            tip.weight or 0,
                            tip.text or ""
                        )
                    else
                        displayText = string.format("%s %s (%d)%s\n%s", typeMarkup, tip.id or "-", tip.weight or 0, statusLabel, tip.text or "")
                    end
                    row.text:SetText(displayText)
                    row.edit.tipID = tip.id
                    row.toggle.tipID = tip.id
                    row.reset.tipID = tip.id
                    if tip.canModify then
                        row.edit:Show()
                        row.toggle:SetText(tip.hidden and getBrowserLocaleString("unhide") or getBrowserLocaleString("hide"))
                        row.toggle:Show()
                        row.reset:Show()
                    else
                        row.edit:Hide()
                        row.toggle:Hide()
                        row.reset:Hide()
                    end
                    row:Show()
                end
            end
        end
    end

    expansionButton = createCycleButton(editorContent, "EditorExpansion", getExpansionKeys(), function(value)
        editorState.expansionKey = value
        editorState.instanceKey = nil
        editorState.npcID = nil
        updateEditorUI()
    end)
    expansionButton:SetPoint("TOPLEFT", expansionFS, "BOTTOMLEFT", 0, -8)
    expansionButton.labelForValue = function(value)
        local expansionData = getExpansionData(value)
        return getLocalizedLabel(expansionData and expansionData.name, value)
    end

    instanceFS = createString(editorContent, getBrowserLocaleString("dungeon_or_raid"), headerFont, headerSize)
    instanceFS:SetPoint("TOPLEFT", expansionButton, "BOTTOMLEFT", 0, -24)

    instanceDropdown = createValueDropdown(editorContent, "EditorInstance", 220, function(value)
        editorState.instanceKey = value
        editorState.npcID = nil
        updateEditorUI()
    end)
    instanceDropdown:SetPoint("TOPLEFT", instanceFS, "BOTTOMLEFT", -16, -2)
    instanceDropdown.labelForValue = function(value)
        if isInstanceGroupEntry(value) then
            return getInstanceGroupLabel(value)
        end
        local instanceData = getInstanceData(editorState.expansionKey, value)
        if not instanceData then
            return value or "-"
        end

        return string.format("%s (%s)", getLocalizedLabel(instanceData.name, value), instanceData.type or "Unknown")
    end

    editorNpcSelectors = createNpcSelectorControls(
        editorContent,
        "EditorNpc",
        editorState,
        instanceDropdown,
        headerFont,
        headerSize,
        updateEditorUI
    )

    selectionSummary = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    selectionSummary:SetPoint("TOPLEFT", editorNpcSelectors.lastDropdown, "BOTTOMLEFT", 16, -18)
    selectionSummary:SetWidth(620)

    npcPreviewFS = createString(editorContent, getBrowserLocaleString("npc_tips"), headerFont, headerSize)
    npcPreviewFS:SetPoint("TOPLEFT", selectionSummary, "BOTTOMLEFT", 0, -18)

    npcPreview = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    npcPreview:SetPoint("TOPLEFT", npcPreviewFS, "BOTTOMLEFT", 0, -6)
    npcPreview:SetWidth(620)

    addTipHeader = createString(editorContent, getBrowserLocaleString("add_npc_tip"), headerFont, headerSize)
    addTipHeader:SetPoint("TOPLEFT", npcPreview, "BOTTOMLEFT", 0, -22)

    addTipTypeLabel = createString(editorContent, getBrowserLocaleString("tip_type"), "Fonts\\FRIZQT__.TTF", 11)
    addTipTypeLabel:SetPoint("TOPLEFT", addTipHeader, "BOTTOMLEFT", 0, -8)

    addTipTypeDropdown = createValueDropdown(editorContent, "EditorAddTipType", 220, function(value) end)
    addTipTypeDropdown:SetPoint("TOPLEFT", addTipTypeLabel, "BOTTOMLEFT", -16, -2)
    addTipTypeDropdown:SetValues(authorTipTypes)
    addTipTypeDropdown.labelForValue = function(value)
        return tostring(value or "-")
    end
    addTipTypeDropdown:SetCurrentValue("Personal")

    addTipWeightLabel = createString(editorContent, getBrowserLocaleString("tip_weight"), "Fonts\\FRIZQT__.TTF", 11)
    addTipWeightLabel:SetPoint("TOPLEFT", addTipTypeDropdown, "TOPRIGHT", 40, 2)

    addTipWeightEdit = createSingleLineInput(editorContent, 70, 24)
    addTipWeightEdit:SetPoint("TOPLEFT", addTipWeightLabel, "BOTTOMLEFT", 0, -6)
    addTipWeightEdit:SetText("5")

    addTipTextLabel = createString(editorContent, getBrowserLocaleString("tip_text"), "Fonts\\FRIZQT__.TTF", 11)
    addTipTextLabel:SetPoint("TOPLEFT", addTipTypeDropdown, "BOTTOMLEFT", 16, -18)

    local addTipTextContainer
    addTipTextContainer, addTipTextBox = createMultiLineInput(editorContent, 620, 96)
    addTipTextContainer:SetPoint("TOPLEFT", addTipTextLabel, "BOTTOMLEFT", 0, -8)
    addTipTextBox:SetText(getBrowserLocaleString("default_tip_text"))

    saveTipButton = CreateFrame("Button", "TDTEditorSaveNpcTip", editorContent, "UIPanelButtonTemplate")
    saveTipButton:SetSize(140, 24)
    saveTipButton:SetPoint("TOPLEFT", addTipTextContainer, "BOTTOMLEFT", 0, -12)
    saveTipButton:SetText(getBrowserLocaleString("save_tip"))

    cancelEditButton = CreateFrame("Button", "TDTEditorCancelNpcTipEdit", editorContent, "UIPanelButtonTemplate")
    cancelEditButton:SetSize(140, 24)
    cancelEditButton:SetPoint("LEFT", saveTipButton, "RIGHT", 12, 0)
    cancelEditButton:SetText(getBrowserLocaleString("cancel_edit"))
    cancelEditButton:Hide()

    addTipStatus = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    addTipStatus:SetPoint("TOPLEFT", saveTipButton, "BOTTOMLEFT", 0, -8)
    addTipStatus:SetWidth(620)

    personalTipsHeader = createString(editorContent, getBrowserLocaleString("personal_tips"), headerFont, headerSize)
    personalTipsHeader:SetPoint("TOPLEFT", addTipStatus, "BOTTOMLEFT", 0, -22)

    for index = 1, 10 do
        local row = CreateFrame("Frame", nil, editorContent)
        row:SetSize(620, 58)
        if index == 1 then
            row:SetPoint("TOPLEFT", personalTipsHeader, "BOTTOMLEFT", 0, -8)
        else
            row:SetPoint("TOPLEFT", personalTipRows[index - 1], "BOTTOMLEFT", 0, -10)
        end

        row.text = createString(row, "", "Fonts\\FRIZQT__.TTF", 11)
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
        row.text:SetWidth(340)

        row.edit = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.edit:SetSize(80, 22)
        row.edit:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 0)
        row.edit:SetText(getBrowserLocaleString("edit"))
        row.edit:SetScript("OnClick", function(self)
            local additions = addon:getNpcUserAdditions(editorState.npcID)
            for _, addition in ipairs(additions) do
                if addition.id == self.tipID then
                    editingBaseTipID = nil
                    editingTipID = addition.id
                    setTipTypeDropdownInteractive(true)
                    addTipTypeDropdown:SetCurrentValue(addition.type or "Personal")
                    addTipWeightEdit:SetText(tostring(addition.weight or 5))
                    addTipTextBox:SetText(addition.text or "")
                    saveTipButton:SetText(getBrowserLocaleString("update_tip"))
                    cancelEditButton:Show()
                    addTipStatus:SetText(getBrowserLocaleString("edit_loaded"))
                    break
                end
            end
        end)

        row.toggle = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.toggle:SetSize(80, 22)
        row.toggle:SetPoint("TOPRIGHT", row.edit, "BOTTOMRIGHT", 0, -6)
        row.toggle:SetScript("OnClick", function(self)
            if addon.setNpcUserTipHidden and editorState.npcID and self.tipID then
                local additions = addon:getNpcUserAdditions(editorState.npcID)
                for _, addition in ipairs(additions) do
                    if addition.id == self.tipID then
                        addon:setNpcUserTipHidden(editorState.npcID, self.tipID, not addition.hidden)
                        updateEditorUI()
                        break
                    end
                end
            end
        end)

        row.delete = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.delete:SetSize(80, 22)
        row.delete:SetPoint("TOPRIGHT", row.toggle, "BOTTOMRIGHT", 0, -6)
        row.delete:SetText(getBrowserLocaleString("delete"))
        row.delete:SetScript("OnClick", function(self)
            if addon.deleteNpcUserTip and editorState.npcID and self.tipID then
                if editingTipID == self.tipID then
                    editingTipID = nil
                    addTipTextBox:SetText("")
                    addTipWeightEdit:SetText("5")
                    addTipTypeDropdown:SetCurrentValue("Personal")
                    saveTipButton:SetText(getBrowserLocaleString("save_tip"))
                    cancelEditButton:Hide()
                end
                addon:deleteNpcUserTip(editorState.npcID, self.tipID)
                updateEditorUI()
            end
        end)

        row:Hide()
        personalTipRows[index] = row
    end

    baseTipsHeader = createString(editorContent, getBrowserLocaleString("base_tips"), headerFont, headerSize)
    baseTipsHeader:SetPoint("TOPLEFT", addTipStatus, "BOTTOMLEFT", 0, -22)

    for index = 1, 14 do
        local row = CreateFrame("Frame", nil, editorContent)
        row:SetSize(620, 78)
        if index == 1 then
            row:SetPoint("TOPLEFT", baseTipsHeader, "BOTTOMLEFT", 0, -8)
        else
            row:SetPoint("TOPLEFT", baseTipRows[index - 1], "BOTTOMLEFT", 0, -10)
        end

        row.text = createString(row, "", "Fonts\\FRIZQT__.TTF", 11)
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
        row.text:SetWidth(430)

        row.toggle = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.toggle:SetSize(80, 22)
        row.toggle:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 0)
        row.toggle:SetScript("OnClick", function(self)
            if addon.setNpcBaseTipHidden and editorState.npcID and self.tipID then
                local baseTips = addon:getNpcBaseTipsForEditor(editorState.npcID)
                for _, baseTip in ipairs(baseTips) do
                    if baseTip.id == self.tipID then
                        addon:setNpcBaseTipHidden(editorState.npcID, self.tipID, not baseTip.hidden)
                        updateEditorUI()
                        break
                    end
                end
            end
        end)

        row.reset = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.reset:SetSize(80, 22)
        row.reset:SetPoint("TOPRIGHT", row.toggle, "BOTTOMRIGHT", 0, -6)
        row.reset:SetText(getBrowserLocaleString("reset"))
        row.reset:SetScript("OnClick", function(self)
            if addon.resetNpcBaseTip and editorState.npcID and self.tipID then
                if editingBaseTipID == self.tipID then
                    editingBaseTipID = nil
                    addTipTextBox:SetText("")
                    addTipWeightEdit:SetText("5")
                    addTipTypeDropdown:SetCurrentValue("Personal")
                    setTipTypeDropdownInteractive(true)
                    saveTipButton:SetText(getBrowserLocaleString("save_tip"))
                    cancelEditButton:Hide()
                end
                addon:resetNpcBaseTip(editorState.npcID, self.tipID)
                updateEditorUI()
            end
        end)

        row.edit = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.edit:SetSize(80, 22)
        row.edit:SetPoint("TOPRIGHT", row.reset, "BOTTOMRIGHT", 0, -6)
        row.edit:SetText(getBrowserLocaleString("edit_base"))
        row.edit:SetScript("OnClick", function(self)
            local baseTips = addon:getNpcBaseTipsForEditor(editorState.npcID)
            for _, baseTip in ipairs(baseTips) do
                if baseTip.id == self.tipID and baseTip.canModify then
                    editingTipID = nil
                    editingBaseTipID = baseTip.id
                    addTipTypeDropdown:SetCurrentValue(baseTip.type or "Important")
                    setTipTypeDropdownInteractive(false)
                    addTipWeightEdit:SetText(tostring(baseTip.overrideWeight or baseTip.weight or 0))
                    addTipTextBox:SetText(baseTip.overrideText or baseTip.text or "")
                    saveTipButton:SetText(getBrowserLocaleString("update_base_tip"))
                    cancelEditButton:Show()
                    addTipStatus:SetText(getBrowserLocaleString("base_edit_loaded"))
                    break
                end
            end
        end)

        row:Hide()
        baseTipRows[index] = row
    end

    cancelEditButton:SetScript("OnClick", function()
        editingTipID = nil
        editingBaseTipID = nil
        addTipTextBox:SetText("")
        addTipWeightEdit:SetText("5")
        addTipTypeDropdown:SetCurrentValue("Personal")
        setTipTypeDropdownInteractive(true)
        saveTipButton:SetText(getBrowserLocaleString("save_tip"))
        cancelEditButton:Hide()
        addTipStatus:SetText("")
    end)

    saveTipButton:SetScript("OnClick", function()
        local selectedType = addTipTypeDropdown.currentValue or "Personal"
        local tipText = addTipTextBox:GetText() or ""
        tipText = tipText:gsub("^%s+", ""):gsub("%s+$", "")
        local weight = tonumber(addTipWeightEdit:GetText()) or 5

        if tipText == "" or tipText == getBrowserLocaleString("default_tip_text") then
            addTipStatus:SetText(getBrowserLocaleString("missing_tip"))
            return
        end

        if editorState.npcID and editorState.npcID ~= NPC_NONE then
            if editingTipID and addon.updateNpcUserTip then
                addon:updateNpcUserTip(editorState.npcID, editingTipID, selectedType, tipText, weight)
                addTipStatus:SetText(getBrowserLocaleString("updated_tip"))
            elseif editingBaseTipID and addon.updateNpcBaseTipOverride then
                addon:updateNpcBaseTipOverride(editorState.npcID, editingBaseTipID, tipText, weight)
                addTipStatus:SetText(getBrowserLocaleString("updated_base_tip"))
            elseif addon.addNpcUserTip then
                addon:addNpcUserTip(editorState.npcID, selectedType, tipText, weight)
                addTipStatus:SetText(getBrowserLocaleString("saved_tip"))
            end

            editingTipID = nil
            editingBaseTipID = nil
            addTipTextBox:SetText("")
            addTipWeightEdit:SetText("5")
            addTipTypeDropdown:SetCurrentValue("Personal")
            setTipTypeDropdownInteractive(true)
            saveTipButton:SetText(getBrowserLocaleString("save_tip"))
            cancelEditButton:Hide()
            updateEditorUI()
            if addon.editorPanel.refreshScroll then
                addon.editorPanel:refreshScroll()
            end
        end
    end)

    addon.editorPanel:RegisterEvent("ADDON_LOADED")
    addon.editorPanel:SetScript("OnEvent", function(self, event, arg1)
        if event == "ADDON_LOADED" and arg1 == "Tothys-Dungeon-Tips-TBC" then
            TDTConfig = applyConfigDefaults(TDTConfig)
            editorState.expansionKey = TDTConfig.BrowserExpansionKey
            editorState.instanceKey = TDTConfig.BrowserInstanceKey
            editorState.npcID = TDTConfig.BrowserNpcID
            refreshTipEditorTexts()
            updateEditorUI()
            if self.refreshScroll then self:refreshScroll() end
        end
    end)

    addon.editorPanel:HookScript("OnShow", function()
        refreshTipEditorTexts()
        updateEditorUI()
    end)

    refreshTipEditorTexts()
    updateEditorUI()
end

local function createDungeonEditorMenu()
    addon.dungeonEditorPanel = CreateFrame("Frame", "TothysDungeonTipsDungeonEditor", UIParent)
    addon.dungeonEditorPanel.name = getBrowserLocaleString("dungeon_editor_page")
    addon.dungeonEditorPanel.okay = function(self) return end
    addon.dungeonEditorPanel.cancel = function(self) return end
    local editorContent = setupScrollablePanel(addon.dungeonEditorPanel, "TDTDungeonEditor", 2200)

    local headerFont = "Fonts\\MORPHEUS.ttf"
    local headerSize = 16

    local title = editorContent:CreateFontString()
    title:SetPoint("TOPLEFT", 10, -10)
    title:SetFont("Fonts\\MORPHEUS.ttf", 22, "OUTLINE")
    title:SetTextColor(0.9, 0.68, 0.22, 1)
    title:SetText(getBrowserLocaleString("dungeon_editor_title"))

    local subtitle = createString(editorContent, getBrowserLocaleString("dungeon_editor_subtitle"), "Fonts\\FRIZQT__.TTF", 11)
    subtitle:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -8)
    subtitle:SetWidth(620)

    local editorState = {
        expansionKey = TDTConfig.BrowserExpansionKey,
        instanceKey = TDTConfig.BrowserInstanceKey,
    }

    local expansionButton
    local instanceDropdown
    local selectionSummary
    local instancePreview
    local instanceDetailsPreview
    local addTipTypeDropdown
    local addTipWeightEdit
    local addTipTextBox
    local addTipStatus
    local personalTipsHeader
    local personalTipRows = {}
    local editingTipID = nil
    local editingBaseTipID = nil
    local baseTipsHeader
    local baseTipRows = {}
    local expansionFS
    local instanceFS
    local instancePreviewFS
    local instanceDetailsFS
    local addTipHeader
    local addTipTypeLabel
    local addTipWeightLabel
    local addTipTextLabel
    local saveTipButton
    local cancelEditButton
    local detailsEditorHeader
    local detailsTravelLabel
    local detailsAttunementLabel
    local detailsNotesLabel
    local detailsLoreLabel
    local detailsTravelEdit
    local detailsAttunementEdit
    local detailsNotesEdit
    local detailsLoreEdit
    local detailsTravelOverrideButton
    local detailsTravelResetButton
    local detailsTravelOriginalText
    local detailsAttunementOverrideButton
    local detailsAttunementResetButton
    local detailsAttunementOriginalText
    local detailsNotesOverrideButton
    local detailsNotesResetButton
    local detailsNotesOriginalText
    local detailsLoreOverrideButton
    local detailsLoreResetButton
    local detailsLoreOriginalText
    local detailsStatus

    local function refreshDungeonEditorTexts()
        addon.dungeonEditorPanel.name = getBrowserLocaleString("dungeon_editor_page")
        title:SetText(getBrowserLocaleString("dungeon_editor_title"))
        subtitle:SetText(getBrowserLocaleString("dungeon_editor_subtitle"))
        expansionFS:SetText(getBrowserLocaleString("expansion"))
        instanceFS:SetText(getBrowserLocaleString("dungeon_or_raid"))
        instancePreviewFS:SetText(getBrowserLocaleString("instance_tips_preview"))
        instanceDetailsFS:SetText(getBrowserLocaleString("additional_details"))
        addTipHeader:SetText(getBrowserLocaleString("add_instance_tip"))
        addTipTypeLabel:SetText(getBrowserLocaleString("tip_type"))
        addTipWeightLabel:SetText(getBrowserLocaleString("tip_weight"))
        addTipTextLabel:SetText(getBrowserLocaleString("tip_text"))
        saveTipButton:SetText(editingBaseTipID and getBrowserLocaleString("update_base_tip") or editingTipID and getBrowserLocaleString("update_tip") or getBrowserLocaleString("save_tip"))
        cancelEditButton:SetText(getBrowserLocaleString("cancel_edit"))
        personalTipsHeader:SetText(getBrowserLocaleString("user_instance_tips"))
        baseTipsHeader:SetText(getBrowserLocaleString("addon_instance_tips"))
        detailsEditorHeader:SetText(getBrowserLocaleString("edit_more_infos"))
        detailsTravelLabel:SetText(getBrowserLocaleString("travel"))
        detailsAttunementLabel:SetText(getBrowserLocaleString("attunement"))
        detailsNotesLabel:SetText(getBrowserLocaleString("extra_notes"))
        detailsLoreLabel:SetText(getBrowserLocaleString("lore"))
        detailsTravelOverrideButton:SetText(getBrowserLocaleString("edit_base"))
        detailsTravelResetButton:SetText(getBrowserLocaleString("reset"))
        detailsAttunementOverrideButton:SetText(getBrowserLocaleString("edit_base"))
        detailsAttunementResetButton:SetText(getBrowserLocaleString("reset"))
        detailsNotesOverrideButton:SetText(getBrowserLocaleString("edit_base"))
        detailsNotesResetButton:SetText(getBrowserLocaleString("reset"))
        detailsLoreOverrideButton:SetText(getBrowserLocaleString("edit_base"))
        detailsLoreResetButton:SetText(getBrowserLocaleString("reset"))
        for _, row in ipairs(personalTipRows) do
            row.edit:SetText(getBrowserLocaleString("edit"))
            row.delete:SetText(getBrowserLocaleString("delete"))
        end
        for _, row in ipairs(baseTipRows) do
            row.reset:SetText(getBrowserLocaleString("reset"))
            row.edit:SetText(getBrowserLocaleString("edit_base"))
        end
    end

    local function setTipTypeDropdownInteractive(enabled)
        local alpha = enabled and 1 or 0.5
        addTipTypeDropdown:SetAlpha(alpha)
        local button = _G[addTipTypeDropdown:GetName() .. "Button"]
        if button then
            button:SetEnabled(enabled)
            button:SetAlpha(alpha)
        end
    end

    local function anchorBaseTipsHeader()
        local anchor = addTipStatus
        local offset = -22

        for index = #personalTipRows, 1, -1 do
            if personalTipRows[index]:IsShown() then
                anchor = personalTipRows[index]
                offset = -14
                break
            end
        end

        baseTipsHeader:ClearAllPoints()
        baseTipsHeader:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, offset)
    end

    local function anchorDetailsEditorHeader()
        local anchor = baseTipsHeader
        local offset = -22

        for index = #baseTipRows, 1, -1 do
            if baseTipRows[index]:IsShown() then
                anchor = baseTipRows[index]
                offset = -14
                break
            end
        end

        detailsEditorHeader:ClearAllPoints()
        detailsEditorHeader:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, offset)
    end

    local function renderDungeonEditorPreview(expansionLabel, instanceLabel, mergedInstanceEntries, mergedDetails)
        selectionSummary:SetText(string.format(getBrowserLocaleString("selected_instance"), expansionLabel, instanceLabel))
        instancePreview:SetText(formatTipEntriesPreview(mergedInstanceEntries))
        instanceDetailsPreview:SetText(formatInstanceDetails(mergedDetails))
    end

    local function renderDungeonEditorUserTips(userTips)
        for _, row in ipairs(personalTipRows) do
            row:Hide()
        end

        if #userTips == 0 then
            if personalTipRows[1] then
                personalTipRows[1].text:SetText(getBrowserLocaleString("no_user_instance_tips"))
                personalTipRows[1].toggle:Hide()
                personalTipRows[1].edit:Hide()
                personalTipRows[1].delete:Hide()
                personalTipRows[1]:Show()
            end
            return
        end

        for index, tip in ipairs(userTips) do
            local row = personalTipRows[index]
            if row then
                local hiddenLabel = tip.hidden and (" (" .. getBrowserLocaleString("hidden_tip") .. ")") or ""
                row.text:SetText(string.format("[%s] %s (%d)%s\n%s", tip.type or "?", tip.id or "?", tip.weight or 0, hiddenLabel, tip.text or ""))
                row.edit.tipID = tip.id
                row.toggle:SetText(tip.hidden and getBrowserLocaleString("unhide") or getBrowserLocaleString("hide"))
                row.toggle.tipID = tip.id
                row.delete.tipID = tip.id
                row.edit:Show()
                row.toggle:Show()
                row.delete:Show()
                row:Show()
            end
        end
    end

    local function renderDungeonEditorBaseTips(baseTips)
        for _, row in ipairs(baseTipRows) do
            row:Hide()
        end

        if #baseTips == 0 then
            if baseTipRows[1] then
                baseTipRows[1].text:SetText(getBrowserLocaleString("no_addon_instance_tips"))
                baseTipRows[1].edit:Hide()
                baseTipRows[1].toggle:Hide()
                baseTipRows[1].reset:Hide()
                baseTipRows[1]:Show()
            end
            return
        end

        for index, tip in ipairs(baseTips) do
            local row = baseTipRows[index]
            if row then
                local statusBits = {}
                if tip.hidden then
                    statusBits[#statusBits + 1] = getBrowserLocaleString("hidden_tip")
                end
                if tip.overridden then
                    statusBits[#statusBits + 1] = getBrowserLocaleString("overridden_tip")
                end
                if not tip.canModify then
                    statusBits[#statusBits + 1] = getBrowserLocaleString("legacy_tip")
                end
                local statusLabel = #statusBits > 0 and (" (" .. table.concat(statusBits, ", ") .. ")") or ""
                local typeMarkup = formatTipTypeMarkup(tip.type)
                if tip.overridden and tip.overrideText then
                    local overrideWeight = tip.overrideWeight ~= nil and tip.overrideWeight or tip.weight or 0
                    row.text:SetText(string.format("%s %s (%d)%s\nOverride: %s\nOriginal (%d): %s", typeMarkup, tip.id or "-", overrideWeight, statusLabel, tip.overrideText or "", tip.weight or 0, tip.text or ""))
                else
                    row.text:SetText(string.format("%s %s (%d)%s\n%s", typeMarkup, tip.id or "-", tip.weight or 0, statusLabel, tip.text or ""))
                end
                row.edit.tipID = tip.id
                row.toggle.tipID = tip.id
                row.reset.tipID = tip.id
                if tip.canModify then
                    row.edit:Show()
                    row.toggle:SetText(tip.hidden and getBrowserLocaleString("unhide") or getBrowserLocaleString("hide"))
                    row.toggle:Show()
                    row.reset:Show()
                else
                    row.edit:Hide()
                    row.toggle:Hide()
                    row.reset:Hide()
                end
                row:Show()
            end
        end
    end

    -- Keep field-specific detail rendering together so the main update path stays controller-like.
    local function renderDungeonEditorDetails(detailsData, mergedDetails)
        detailsTravelLabel:SetText(getBrowserLocaleString("travel") .. ((detailsData.travel and detailsData.travel.overridden) and (" (" .. getBrowserLocaleString("overridden_tip") .. ")") or ""))
        detailsAttunementLabel:SetText(getBrowserLocaleString("attunement") .. ((detailsData.attunement and detailsData.attunement.overridden) and (" (" .. getBrowserLocaleString("overridden_tip") .. ")") or ""))
        detailsNotesLabel:SetText(getBrowserLocaleString("extra_notes") .. ((detailsData.notes and detailsData.notes.overridden) and (" (" .. getBrowserLocaleString("overridden_tip") .. ")") or ""))
        detailsLoreLabel:SetText(getBrowserLocaleString("lore") .. ((detailsData.lore and detailsData.lore.overridden) and (" (" .. getBrowserLocaleString("overridden_tip") .. ")") or ""))

        detailsTravelEdit:SetText((detailsData.travel and detailsData.travel.current) or mergedDetails.travel or "")
        detailsAttunementEdit:SetText((detailsData.attunement and detailsData.attunement.current) or mergedDetails.attunement or "")
        detailsNotesEdit:SetText((detailsData.notes and detailsData.notes.current) or mergedDetails.notes or "")
        detailsLoreEdit:SetText((detailsData.lore and detailsData.lore.current) or mergedDetails.lore or "")
        detailsTravelOriginalText:SetText(string.format("%s: %s", getBrowserLocaleString("original_text"), (detailsData.travel and detailsData.travel.base) or ""))
        detailsAttunementOriginalText:SetText(string.format("%s: %s", getBrowserLocaleString("original_text"), (detailsData.attunement and detailsData.attunement.base) or ""))
        detailsNotesOriginalText:SetText(string.format("%s: %s", getBrowserLocaleString("original_text"), (detailsData.notes and detailsData.notes.base) or ""))
        detailsLoreOriginalText:SetText(string.format("%s: %s", getBrowserLocaleString("original_text"), (detailsData.lore and detailsData.lore.base) or ""))
    end

    local function ensureEditorSelection()
        ensureExpansionInstanceSelection(editorState)
    end

    local function updateDungeonEditorUI()
        ensureEditorSelection()
        syncExpansionInstanceControls(editorState, expansionButton, instanceDropdown)

        local expansionData = getExpansionData(editorState.expansionKey)
        local instanceData = getInstanceData(editorState.expansionKey, editorState.instanceKey)
        local expansionLabel = getLocalizedLabel(expansionData and expansionData.name, editorState.expansionKey or "-")
        local instanceLabel = getLocalizedLabel(instanceData and instanceData.name, editorState.instanceKey or "-")
        local mergedInstanceEntries = addon.getMergedInstanceTipEntries and addon:getMergedInstanceTipEntries(editorState.instanceKey) or {}
        local userTips = addon.getInstanceUserAdditions and addon:getInstanceUserAdditions(editorState.instanceKey) or {}
        local baseTips = addon.getInstanceBaseTipsForEditor and addon:getInstanceBaseTipsForEditor(editorState.instanceKey) or {}
        local detailsData = addon.getInstanceDetailsForEditor and addon:getInstanceDetailsForEditor(editorState.instanceKey) or {}
        local mergedDetails = getInstanceDetails(editorState.instanceKey) or {}

        renderDungeonEditorPreview(expansionLabel, instanceLabel, mergedInstanceEntries, mergedDetails)
        renderDungeonEditorUserTips(userTips)
        anchorBaseTipsHeader()
        renderDungeonEditorBaseTips(baseTips)
        anchorDetailsEditorHeader()
        renderDungeonEditorDetails(detailsData, mergedDetails)
    end

    expansionFS = createString(editorContent, getBrowserLocaleString("expansion"), headerFont, headerSize)
    expansionFS:SetPoint("TOPLEFT", subtitle, "BOTTOMLEFT", 0, -20)

    expansionButton = createCycleButton(editorContent, "DungeonEditorExpansion", getExpansionKeys(), function(value)
        editorState.expansionKey = value
        editorState.instanceKey = nil
        updateDungeonEditorUI()
    end)
    expansionButton:SetPoint("TOPLEFT", expansionFS, "BOTTOMLEFT", 0, -8)
    expansionButton.labelForValue = function(value)
        local expansionData = getExpansionData(value)
        return getLocalizedLabel(expansionData and expansionData.name, value)
    end

    instanceFS = createString(editorContent, getBrowserLocaleString("dungeon_or_raid"), headerFont, headerSize)
    instanceFS:SetPoint("TOPLEFT", expansionButton, "BOTTOMLEFT", 0, -24)

    instanceDropdown = createValueDropdown(editorContent, "DungeonEditorInstance", 220, function(value)
        editorState.instanceKey = value
        updateDungeonEditorUI()
    end)
    instanceDropdown:SetPoint("TOPLEFT", instanceFS, "BOTTOMLEFT", -16, -2)
    instanceDropdown.labelForValue = function(value)
        if isInstanceGroupEntry(value) then
            return getInstanceGroupLabel(value)
        end
        local instanceData = getInstanceData(editorState.expansionKey, value)
        if not instanceData then
            return value or "-"
        end

        return string.format("%s (%s)", getLocalizedLabel(instanceData.name, value), instanceData.type or "Unknown")
    end

    selectionSummary = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    selectionSummary:SetPoint("TOPLEFT", instanceDropdown, "BOTTOMLEFT", 16, -18)
    selectionSummary:SetWidth(620)

    instancePreviewFS = createString(editorContent, getBrowserLocaleString("instance_tips_preview"), headerFont, headerSize)
    instancePreviewFS:SetPoint("TOPLEFT", selectionSummary, "BOTTOMLEFT", 0, -18)

    instancePreview = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    instancePreview:SetPoint("TOPLEFT", instancePreviewFS, "BOTTOMLEFT", 0, -6)
    instancePreview:SetWidth(620)

    instanceDetailsFS = createString(editorContent, getBrowserLocaleString("additional_details"), headerFont, headerSize)
    instanceDetailsFS:SetPoint("TOPLEFT", instancePreview, "BOTTOMLEFT", 0, -18)

    instanceDetailsPreview = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    instanceDetailsPreview:SetPoint("TOPLEFT", instanceDetailsFS, "BOTTOMLEFT", 0, -6)
    instanceDetailsPreview:SetWidth(620)

    addTipHeader = createString(editorContent, getBrowserLocaleString("add_instance_tip"), headerFont, headerSize)
    addTipHeader:SetPoint("TOPLEFT", instanceDetailsPreview, "BOTTOMLEFT", 0, -22)

    addTipTypeLabel = createString(editorContent, getBrowserLocaleString("tip_type"), "Fonts\\FRIZQT__.TTF", 11)
    addTipTypeLabel:SetPoint("TOPLEFT", addTipHeader, "BOTTOMLEFT", 0, -8)

    addTipTypeDropdown = createValueDropdown(editorContent, "DungeonEditorAddTipType", 220, function(value) end)
    addTipTypeDropdown:SetPoint("TOPLEFT", addTipTypeLabel, "BOTTOMLEFT", -16, -2)
    addTipTypeDropdown:SetValues(authorTipTypes)
    addTipTypeDropdown.labelForValue = function(value)
        return tostring(value or "-")
    end
    addTipTypeDropdown:SetCurrentValue("Personal")

    addTipWeightLabel = createString(editorContent, getBrowserLocaleString("tip_weight"), "Fonts\\FRIZQT__.TTF", 11)
    addTipWeightLabel:SetPoint("TOPLEFT", addTipTypeDropdown, "TOPRIGHT", 40, 2)

    addTipWeightEdit = createSingleLineInput(editorContent, 70, 24)
    addTipWeightEdit:SetPoint("TOPLEFT", addTipWeightLabel, "BOTTOMLEFT", 0, -6)
    addTipWeightEdit:SetText("5")

    addTipTextLabel = createString(editorContent, getBrowserLocaleString("tip_text"), "Fonts\\FRIZQT__.TTF", 11)
    addTipTextLabel:SetPoint("TOPLEFT", addTipTypeDropdown, "BOTTOMLEFT", 16, -18)

    local addTipTextContainer
    addTipTextContainer, addTipTextBox = createMultiLineInput(editorContent, 620, 96)
    addTipTextContainer:SetPoint("TOPLEFT", addTipTextLabel, "BOTTOMLEFT", 0, -8)
    addTipTextBox:SetText(getBrowserLocaleString("default_instance_tip_text"))

    saveTipButton = CreateFrame("Button", "TDTDungeonEditorSaveTip", editorContent, "UIPanelButtonTemplate")
    saveTipButton:SetSize(140, 24)
    saveTipButton:SetPoint("TOPLEFT", addTipTextContainer, "BOTTOMLEFT", 0, -12)
    saveTipButton:SetText(getBrowserLocaleString("save_tip"))

    cancelEditButton = CreateFrame("Button", "TDTDungeonEditorCancelTipEdit", editorContent, "UIPanelButtonTemplate")
    cancelEditButton:SetSize(140, 24)
    cancelEditButton:SetPoint("LEFT", saveTipButton, "RIGHT", 12, 0)
    cancelEditButton:SetText(getBrowserLocaleString("cancel_edit"))
    cancelEditButton:Hide()

    addTipStatus = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    addTipStatus:SetPoint("TOPLEFT", saveTipButton, "BOTTOMLEFT", 0, -8)
    addTipStatus:SetWidth(620)

    personalTipsHeader = createString(editorContent, getBrowserLocaleString("user_instance_tips"), headerFont, headerSize)
    personalTipsHeader:SetPoint("TOPLEFT", addTipStatus, "BOTTOMLEFT", 0, -22)

    for index = 1, 10 do
        local row = CreateFrame("Frame", nil, editorContent)
        row:SetSize(620, 58)
        if index == 1 then
            row:SetPoint("TOPLEFT", personalTipsHeader, "BOTTOMLEFT", 0, -8)
        else
            row:SetPoint("TOPLEFT", personalTipRows[index - 1], "BOTTOMLEFT", 0, -10)
        end

        row.text = createString(row, "", "Fonts\\FRIZQT__.TTF", 11)
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
        row.text:SetWidth(340)

        row.edit = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.edit:SetSize(80, 22)
        row.edit:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 0)
        row.edit:SetText(getBrowserLocaleString("edit"))
        row.edit:SetScript("OnClick", function(self)
            local additions = addon:getInstanceUserAdditions(editorState.instanceKey)
            for _, addition in ipairs(additions) do
                if addition.id == self.tipID then
                    editingBaseTipID = nil
                    editingTipID = addition.id
                    setTipTypeDropdownInteractive(true)
                    addTipTypeDropdown:SetCurrentValue(addition.type or "Personal")
                    addTipWeightEdit:SetText(tostring(addition.weight or 5))
                    addTipTextBox:SetText(addition.text or "")
                    saveTipButton:SetText(getBrowserLocaleString("update_tip"))
                    cancelEditButton:Show()
                    addTipStatus:SetText(getBrowserLocaleString("instance_edit_loaded"))
                    break
                end
            end
        end)

        row.toggle = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.toggle:SetSize(80, 22)
        row.toggle:SetPoint("TOPRIGHT", row.edit, "BOTTOMRIGHT", 0, -6)
        row.toggle:SetScript("OnClick", function(self)
            if addon.setInstanceUserTipHidden and editorState.instanceKey and self.tipID then
                local additions = addon:getInstanceUserAdditions(editorState.instanceKey)
                for _, addition in ipairs(additions) do
                    if addition.id == self.tipID then
                        addon:setInstanceUserTipHidden(editorState.instanceKey, self.tipID, not addition.hidden)
                        updateDungeonEditorUI()
                        break
                    end
                end
            end
        end)

        row.delete = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.delete:SetSize(80, 22)
        row.delete:SetPoint("TOPRIGHT", row.toggle, "BOTTOMRIGHT", 0, -6)
        row.delete:SetText(getBrowserLocaleString("delete"))
        row.delete:SetScript("OnClick", function(self)
            if addon.deleteInstanceUserTip and editorState.instanceKey and self.tipID then
                if editingTipID == self.tipID then
                    editingTipID = nil
                    editingBaseTipID = nil
                    addTipTextBox:SetText("")
                    addTipWeightEdit:SetText("5")
                    addTipTypeDropdown:SetCurrentValue("Personal")
                    setTipTypeDropdownInteractive(true)
                    saveTipButton:SetText(getBrowserLocaleString("save_tip"))
                    cancelEditButton:Hide()
                end
                addon:deleteInstanceUserTip(editorState.instanceKey, self.tipID)
                updateDungeonEditorUI()
            end
        end)

        row:Hide()
        personalTipRows[index] = row
    end

    baseTipsHeader = createString(editorContent, getBrowserLocaleString("addon_instance_tips"), headerFont, headerSize)
    baseTipsHeader:SetPoint("TOPLEFT", addTipStatus, "BOTTOMLEFT", 0, -22)

    for index = 1, 10 do
        local row = CreateFrame("Frame", nil, editorContent)
        row:SetSize(620, 78)
        if index == 1 then
            row:SetPoint("TOPLEFT", baseTipsHeader, "BOTTOMLEFT", 0, -8)
        else
            row:SetPoint("TOPLEFT", baseTipRows[index - 1], "BOTTOMLEFT", 0, -10)
        end

        row.text = createString(row, "", "Fonts\\FRIZQT__.TTF", 11)
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", 0, 0)
        row.text:SetWidth(430)

        row.toggle = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.toggle:SetSize(80, 22)
        row.toggle:SetPoint("TOPRIGHT", row, "TOPRIGHT", 0, 0)
        row.toggle:SetScript("OnClick", function(self)
            if addon.setInstanceBaseTipHidden and editorState.instanceKey and self.tipID then
                local baseTips = addon:getInstanceBaseTipsForEditor(editorState.instanceKey)
                for _, baseTip in ipairs(baseTips) do
                    if baseTip.id == self.tipID then
                        addon:setInstanceBaseTipHidden(editorState.instanceKey, self.tipID, not baseTip.hidden)
                        updateDungeonEditorUI()
                        break
                    end
                end
            end
        end)

        row.reset = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.reset:SetSize(80, 22)
        row.reset:SetPoint("TOPRIGHT", row.toggle, "BOTTOMRIGHT", 0, -6)
        row.reset:SetText(getBrowserLocaleString("reset"))
        row.reset:SetScript("OnClick", function(self)
            if addon.resetInstanceBaseTip and editorState.instanceKey and self.tipID then
                if editingBaseTipID == self.tipID then
                    editingBaseTipID = nil
                    addTipTextBox:SetText("")
                    addTipWeightEdit:SetText("5")
                    addTipTypeDropdown:SetCurrentValue("Personal")
                    setTipTypeDropdownInteractive(true)
                    saveTipButton:SetText(getBrowserLocaleString("save_tip"))
                    cancelEditButton:Hide()
                end
                addon:resetInstanceBaseTip(editorState.instanceKey, self.tipID)
                updateDungeonEditorUI()
            end
        end)

        row.edit = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.edit:SetSize(80, 22)
        row.edit:SetPoint("TOPRIGHT", row.reset, "BOTTOMRIGHT", 0, -6)
        row.edit:SetText(getBrowserLocaleString("edit_base"))
        row.edit:SetScript("OnClick", function(self)
            local baseTips = addon:getInstanceBaseTipsForEditor(editorState.instanceKey)
            for _, baseTip in ipairs(baseTips) do
                if baseTip.id == self.tipID and baseTip.canModify then
                    editingTipID = nil
                    editingBaseTipID = baseTip.id
                    addTipTypeDropdown:SetCurrentValue(baseTip.type or "Important")
                    setTipTypeDropdownInteractive(false)
                    addTipWeightEdit:SetText(tostring(baseTip.overrideWeight or baseTip.weight or 0))
                    addTipTextBox:SetText(baseTip.overrideText or baseTip.text or "")
                    saveTipButton:SetText(getBrowserLocaleString("update_base_tip"))
                    cancelEditButton:Show()
                    addTipStatus:SetText(getBrowserLocaleString("base_instance_edit_loaded"))
                    break
                end
            end
        end)

        row:Hide()
        baseTipRows[index] = row
    end

    detailsEditorHeader = createString(editorContent, getBrowserLocaleString("edit_more_infos"), headerFont, headerSize)
    detailsEditorHeader:SetPoint("TOPLEFT", baseTipsHeader, "BOTTOMLEFT", 0, -22)

    detailsTravelLabel = createString(editorContent, getBrowserLocaleString("travel"), "Fonts\\FRIZQT__.TTF", 11)
    detailsTravelLabel:SetPoint("TOPLEFT", detailsEditorHeader, "BOTTOMLEFT", 0, -8)
    local detailsTravelContainer
    detailsTravelContainer, detailsTravelEdit = createMultiLineInput(editorContent, 620, 56)
    detailsTravelContainer:SetPoint("TOPLEFT", detailsTravelLabel, "BOTTOMLEFT", 0, -8)
    detailsTravelOverrideButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsTravelOverrideButton:SetSize(90, 22)
    detailsTravelOverrideButton:SetPoint("TOPLEFT", detailsTravelContainer, "BOTTOMLEFT", 0, -8)
    detailsTravelResetButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsTravelResetButton:SetSize(90, 22)
    detailsTravelResetButton:SetPoint("LEFT", detailsTravelOverrideButton, "RIGHT", 8, 0)
    detailsTravelOriginalText = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    detailsTravelOriginalText:SetPoint("TOPLEFT", detailsTravelOverrideButton, "BOTTOMLEFT", 0, -8)
    detailsTravelOriginalText:SetWidth(620)

    detailsAttunementLabel = createString(editorContent, getBrowserLocaleString("attunement"), "Fonts\\FRIZQT__.TTF", 11)
    detailsAttunementLabel:SetPoint("TOPLEFT", detailsTravelOriginalText, "BOTTOMLEFT", 0, -14)
    local detailsAttunementContainer
    detailsAttunementContainer, detailsAttunementEdit = createMultiLineInput(editorContent, 620, 56)
    detailsAttunementContainer:SetPoint("TOPLEFT", detailsAttunementLabel, "BOTTOMLEFT", 0, -8)
    detailsAttunementOverrideButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsAttunementOverrideButton:SetSize(90, 22)
    detailsAttunementOverrideButton:SetPoint("TOPLEFT", detailsAttunementContainer, "BOTTOMLEFT", 0, -8)
    detailsAttunementResetButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsAttunementResetButton:SetSize(90, 22)
    detailsAttunementResetButton:SetPoint("LEFT", detailsAttunementOverrideButton, "RIGHT", 8, 0)
    detailsAttunementOriginalText = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    detailsAttunementOriginalText:SetPoint("TOPLEFT", detailsAttunementOverrideButton, "BOTTOMLEFT", 0, -8)
    detailsAttunementOriginalText:SetWidth(620)

    detailsNotesLabel = createString(editorContent, getBrowserLocaleString("extra_notes"), "Fonts\\FRIZQT__.TTF", 11)
    detailsNotesLabel:SetPoint("TOPLEFT", detailsAttunementOriginalText, "BOTTOMLEFT", 0, -14)
    local detailsNotesContainer
    detailsNotesContainer, detailsNotesEdit = createMultiLineInput(editorContent, 620, 72)
    detailsNotesContainer:SetPoint("TOPLEFT", detailsNotesLabel, "BOTTOMLEFT", 0, -8)
    detailsNotesOverrideButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsNotesOverrideButton:SetSize(90, 22)
    detailsNotesOverrideButton:SetPoint("TOPLEFT", detailsNotesContainer, "BOTTOMLEFT", 0, -8)
    detailsNotesResetButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsNotesResetButton:SetSize(90, 22)
    detailsNotesResetButton:SetPoint("LEFT", detailsNotesOverrideButton, "RIGHT", 8, 0)
    detailsNotesOriginalText = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    detailsNotesOriginalText:SetPoint("TOPLEFT", detailsNotesOverrideButton, "BOTTOMLEFT", 0, -8)
    detailsNotesOriginalText:SetWidth(620)

    detailsLoreLabel = createString(editorContent, getBrowserLocaleString("lore"), "Fonts\\FRIZQT__.TTF", 11)
    detailsLoreLabel:SetPoint("TOPLEFT", detailsNotesOriginalText, "BOTTOMLEFT", 0, -14)
    local detailsLoreContainer
    detailsLoreContainer, detailsLoreEdit = createMultiLineInput(editorContent, 620, 72)
    detailsLoreContainer:SetPoint("TOPLEFT", detailsLoreLabel, "BOTTOMLEFT", 0, -8)
    detailsLoreOverrideButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsLoreOverrideButton:SetSize(90, 22)
    detailsLoreOverrideButton:SetPoint("TOPLEFT", detailsLoreContainer, "BOTTOMLEFT", 0, -8)
    detailsLoreResetButton = CreateFrame("Button", nil, editorContent, "UIPanelButtonTemplate")
    detailsLoreResetButton:SetSize(90, 22)
    detailsLoreResetButton:SetPoint("LEFT", detailsLoreOverrideButton, "RIGHT", 8, 0)
    detailsLoreOriginalText = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    detailsLoreOriginalText:SetPoint("TOPLEFT", detailsLoreOverrideButton, "BOTTOMLEFT", 0, -8)
    detailsLoreOriginalText:SetWidth(620)

    detailsStatus = createString(editorContent, "", "Fonts\\FRIZQT__.TTF", 11)
    detailsStatus:SetPoint("TOPLEFT", detailsLoreOriginalText, "BOTTOMLEFT", 0, -12)
    detailsStatus:SetWidth(620)

    cancelEditButton:SetScript("OnClick", function()
        editingTipID = nil
        editingBaseTipID = nil
        addTipTextBox:SetText("")
        addTipWeightEdit:SetText("5")
        addTipTypeDropdown:SetCurrentValue("Personal")
        setTipTypeDropdownInteractive(true)
        saveTipButton:SetText(getBrowserLocaleString("save_tip"))
        cancelEditButton:Hide()
        addTipStatus:SetText("")
    end)

    saveTipButton:SetScript("OnClick", function()
        local selectedType = addTipTypeDropdown.currentValue or "Personal"
        local tipText = addTipTextBox:GetText() or ""
        tipText = tipText:gsub("^%s+", ""):gsub("%s+$", "")
        local weight = tonumber(addTipWeightEdit:GetText()) or 5

        if tipText == "" or tipText == getBrowserLocaleString("default_instance_tip_text") then
            addTipStatus:SetText(getBrowserLocaleString("missing_tip"))
            return
        end

        if editorState.instanceKey then
            if editingTipID and addon.updateInstanceUserTip then
                addon:updateInstanceUserTip(editorState.instanceKey, editingTipID, selectedType, tipText, weight)
                addTipStatus:SetText(getBrowserLocaleString("updated_instance_tip"))
            elseif editingBaseTipID and addon.updateInstanceBaseTipOverride then
                addon:updateInstanceBaseTipOverride(editorState.instanceKey, editingBaseTipID, tipText, weight)
                addTipStatus:SetText(getBrowserLocaleString("updated_base_instance_tip"))
            elseif addon.addInstanceUserTip then
                addon:addInstanceUserTip(editorState.instanceKey, selectedType, tipText, weight)
                addTipStatus:SetText(getBrowserLocaleString("saved_instance_tip"))
            end

            editingTipID = nil
            editingBaseTipID = nil
            addTipTextBox:SetText("")
            addTipWeightEdit:SetText("5")
            addTipTypeDropdown:SetCurrentValue("Personal")
            setTipTypeDropdownInteractive(true)
            saveTipButton:SetText(getBrowserLocaleString("save_tip"))
            cancelEditButton:Hide()
            updateDungeonEditorUI()
            if addon.dungeonEditorPanel.refreshScroll then
                addon.dungeonEditorPanel:refreshScroll()
            end
        end
    end)

    detailsTravelOverrideButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.updateInstanceDetailsOverrides then
            addon:updateInstanceDetailsOverrides(editorState.instanceKey, { travel = detailsTravelEdit:GetText() or "" })
            detailsStatus:SetText(getBrowserLocaleString("more_infos_saved"))
            updateDungeonEditorUI()
        end
    end)
    detailsTravelResetButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.resetInstanceDetailsOverrides then
            addon:resetInstanceDetailsOverrides(editorState.instanceKey, "travel")
            detailsStatus:SetText(getBrowserLocaleString("more_infos_reset"))
            updateDungeonEditorUI()
        end
    end)
    detailsAttunementOverrideButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.updateInstanceDetailsOverrides then
            addon:updateInstanceDetailsOverrides(editorState.instanceKey, { attunement = detailsAttunementEdit:GetText() or "" })
            detailsStatus:SetText(getBrowserLocaleString("more_infos_saved"))
            updateDungeonEditorUI()
        end
    end)
    detailsAttunementResetButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.resetInstanceDetailsOverrides then
            addon:resetInstanceDetailsOverrides(editorState.instanceKey, "attunement")
            detailsStatus:SetText(getBrowserLocaleString("more_infos_reset"))
            updateDungeonEditorUI()
        end
    end)
    detailsNotesOverrideButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.updateInstanceDetailsOverrides then
            addon:updateInstanceDetailsOverrides(editorState.instanceKey, { notes = detailsNotesEdit:GetText() or "" })
            detailsStatus:SetText(getBrowserLocaleString("more_infos_saved"))
            updateDungeonEditorUI()
        end
    end)
    detailsNotesResetButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.resetInstanceDetailsOverrides then
            addon:resetInstanceDetailsOverrides(editorState.instanceKey, "notes")
            detailsStatus:SetText(getBrowserLocaleString("more_infos_reset"))
            updateDungeonEditorUI()
        end
    end)
    detailsLoreOverrideButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.updateInstanceDetailsOverrides then
            addon:updateInstanceDetailsOverrides(editorState.instanceKey, { lore = detailsLoreEdit:GetText() or "" })
            detailsStatus:SetText(getBrowserLocaleString("more_infos_saved"))
            updateDungeonEditorUI()
        end
    end)
    detailsLoreResetButton:SetScript("OnClick", function()
        if editorState.instanceKey and addon.resetInstanceDetailsOverrides then
            addon:resetInstanceDetailsOverrides(editorState.instanceKey, "lore")
            detailsStatus:SetText(getBrowserLocaleString("more_infos_reset"))
            updateDungeonEditorUI()
        end
    end)

    addon.dungeonEditorPanel:RegisterEvent("ADDON_LOADED")
    addon.dungeonEditorPanel:SetScript("OnEvent", function(self, event, arg1)
        if event == "ADDON_LOADED" and arg1 == "Tothys-Dungeon-Tips-TBC" then
            TDTConfig = applyConfigDefaults(TDTConfig)
            editorState.expansionKey = TDTConfig.BrowserExpansionKey
            editorState.instanceKey = TDTConfig.BrowserInstanceKey
            refreshDungeonEditorTexts()
            updateDungeonEditorUI()
            if self.refreshScroll then self:refreshScroll() end
        end
    end)

    addon.dungeonEditorPanel:HookScript("OnShow", function()
        refreshDungeonEditorTexts()
        updateDungeonEditorUI()
    end)

    refreshDungeonEditorTexts()
    updateDungeonEditorUI()
end

local function createInfoMenu()
    addon.infoPanel = CreateFrame("Frame", "TothysDungeonTipsInfo", UIParent)
    addon.infoPanel.name = "Info"
    addon.infoPanel.okay = function(self) return end
    addon.infoPanel.cancel = function(self) return end
    local infoContent = setupScrollablePanel(addon.infoPanel, "TDTInfo", 980)

    local title = infoContent:CreateFontString()
    title:SetPoint("TOPLEFT", 10, -10)
    title:SetFont("Fonts\\MORPHEUS.ttf", 22, "OUTLINE")
    title:SetTextColor(0.9, 0.68, 0.22, 1)
    title:SetText(getBrowserLocaleString("info_title"))

    local intro = createString(infoContent, getBrowserLocaleString("info_intro"), "Fonts\\FRIZQT__.TTF", 12)
    intro:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -10)
    intro:SetWidth(620)

    local originHeader = createString(infoContent, getBrowserLocaleString("info_background"), "Fonts\\MORPHEUS.ttf", 16)
    originHeader:SetPoint("TOPLEFT", intro, "BOTTOMLEFT", 0, -18)

    local originText = createString(infoContent, getBrowserLocaleString("info_background_text"), "Fonts\\FRIZQT__.TTF", 11)
    originText:SetPoint("TOPLEFT", originHeader, "BOTTOMLEFT", 0, -8)
    originText:SetWidth(620)

    local statusHeader = createString(infoContent, getBrowserLocaleString("info_status"), "Fonts\\MORPHEUS.ttf", 16)
    statusHeader:SetPoint("TOPLEFT", originText, "BOTTOMLEFT", 0, -18)

    local statusText = createString(infoContent, getBrowserLocaleString("info_status_text"), "Fonts\\FRIZQT__.TTF", 11)
    statusText:SetPoint("TOPLEFT", statusHeader, "BOTTOMLEFT", 0, -8)
    statusText:SetWidth(620)

    local roadmapHeader = createString(infoContent, getBrowserLocaleString("info_focus"), "Fonts\\MORPHEUS.ttf", 16)
    roadmapHeader:SetPoint("TOPLEFT", statusText, "BOTTOMLEFT", 0, -18)

    local roadmapText = createString(infoContent, getBrowserLocaleString("info_focus_text"), "Fonts\\FRIZQT__.TTF", 11)
    roadmapText:SetPoint("TOPLEFT", roadmapHeader, "BOTTOMLEFT", 0, -8)
    roadmapText:SetWidth(620)

    local howHeader = createString(infoContent, getBrowserLocaleString("info_how_it_works"), "Fonts\\MORPHEUS.ttf", 16)
    howHeader:SetPoint("TOPLEFT", roadmapText, "BOTTOMLEFT", 0, -18)

    local howText = createString(infoContent, getBrowserLocaleString("info_how_it_works_text"), "Fonts\\FRIZQT__.TTF", 11)
    howText:SetPoint("TOPLEFT", howHeader, "BOTTOMLEFT", 0, -8)
    howText:SetWidth(620)

    local feedbackHeader = createString(infoContent, getBrowserLocaleString("info_feedback"), "Fonts\\MORPHEUS.ttf", 16)
    feedbackHeader:SetPoint("TOPLEFT", howText, "BOTTOMLEFT", 0, -18)

    local feedbackText = createString(infoContent, getBrowserLocaleString("info_feedback_text"), "Fonts\\FRIZQT__.TTF", 11)
    feedbackText:SetPoint("TOPLEFT", feedbackHeader, "BOTTOMLEFT", 0, -8)
    feedbackText:SetWidth(620)

    local slashHeader = createString(infoContent, getBrowserLocaleString("info_slash_commands"), "Fonts\\MORPHEUS.ttf", 16)
    slashHeader:SetPoint("TOPLEFT", feedbackText, "BOTTOMLEFT", 0, -18)

    local slashText = createString(infoContent, getBrowserLocaleString("info_slash_commands_text"), "Fonts\\FRIZQT__.TTF", 11)
    slashText:SetPoint("TOPLEFT", slashHeader, "BOTTOMLEFT", 0, -8)
    slashText:SetWidth(620)

    local frameClicksHeader = createString(infoContent, getBrowserLocaleString("info_frame_clicks"), "Fonts\\MORPHEUS.ttf", 16)
    frameClicksHeader:SetPoint("TOPLEFT", slashText, "BOTTOMLEFT", 0, -18)

    local frameClicksText = createString(infoContent, getBrowserLocaleString("info_frame_clicks_text"), "Fonts\\FRIZQT__.TTF", 11)
    frameClicksText:SetPoint("TOPLEFT", frameClicksHeader, "BOTTOMLEFT", 0, -8)
    frameClicksText:SetWidth(620)

    local function refreshInfoTexts()
        title:SetText(getBrowserLocaleString("info_title"))
        intro:SetText(getBrowserLocaleString("info_intro"))
        originHeader:SetText(getBrowserLocaleString("info_background"))
        originText:SetText(getBrowserLocaleString("info_background_text"))
        statusHeader:SetText(getBrowserLocaleString("info_status"))
        statusText:SetText(getBrowserLocaleString("info_status_text"))
        roadmapHeader:SetText(getBrowserLocaleString("info_focus"))
        roadmapText:SetText(getBrowserLocaleString("info_focus_text"))
        howHeader:SetText(getBrowserLocaleString("info_how_it_works"))
        howText:SetText(getBrowserLocaleString("info_how_it_works_text"))
        feedbackHeader:SetText(getBrowserLocaleString("info_feedback"))
        feedbackText:SetText(getBrowserLocaleString("info_feedback_text"))
        slashHeader:SetText(getBrowserLocaleString("info_slash_commands"))
        slashText:SetText(getBrowserLocaleString("info_slash_commands_text"))
        frameClicksHeader:SetText(getBrowserLocaleString("info_frame_clicks"))
        frameClicksText:SetText(getBrowserLocaleString("info_frame_clicks_text"))
    end

    addon.infoPanel:SetScript("OnShow", function(self)
        refreshInfoTexts()
        if self.refreshScroll then
            self:refreshScroll()
        end
    end)

    refreshInfoTexts()
end

local function createConfigMenu()

	-- Setup Panel --
	addon.configPanel = CreateFrame("Frame", "TothysDungeonTipsConfiguration", UIParent)
	addon.configPanel.name = "Kiesel Dungeon Tool";
	addon.configPanel.okay = function (self) return end
	addon.configPanel.cancel = function (self) return end
	local configContent = setupScrollablePanel(addon.configPanel, "TDTMainConfig", 1500)
	
	-- Set up Title --
	local ddTitleString = configContent:CreateFontString()
	ddTitleString:SetPoint("TOPLEFT", 10, -10)
	ddTitleString:SetFont("Fonts\\MORPHEUS.ttf", 22, "OUTLINE")
	ddTitleString:SetTextColor(0.9, 0.68, 0.22, 1)
	ddTitleString:SetText(getBrowserLocaleString("config_title"))

	
	-----------------------
	-- Set up Checkboxes --
	-----------------------
	local chkGeneral = createCheck("General", getBrowserLocaleString("config_general"), configContent, function(self, value)
		TDTConfig.Important = self:GetChecked()
	end)
	chkGeneral:SetPoint("TOPLEFT", ddTitleString, "BOTTOMLEFT", 0, -10)
	
	local chkPriority = createCheck("PriorityTargets", getBrowserLocaleString("config_priority"), configContent, function(self, value) TDTConfig.PriorityTargets = self:GetChecked() end)
	chkPriority:SetPoint("TOPLEFT", chkGeneral, "BOTTOMLEFT", 0, -8)
	
	local chkInterrupts = createCheck("Interrupts", getBrowserLocaleString("config_interrupts"), configContent, function(self, value) TDTConfig.Interrupts = self:GetChecked() end)
	chkInterrupts:SetPoint("TOPLEFT", chkPriority, "BOTTOMLEFT", 0, -8)
	
	local chkDefensives = createCheck("Defensives", getBrowserLocaleString("config_defensives"), configContent, function(self, value) TDTConfig.Defensives = self:GetChecked() end)
	chkDefensives:SetPoint("TOPLEFT", chkInterrupts, "BOTTOMLEFT", 0, -8)
	
	local chkFluff = createCheck("Fluff", getBrowserLocaleString("config_fluff"), configContent, function(self, value) TDTConfig.Fluff = self:GetChecked() end)
	chkFluff:SetPoint("TOPLEFT", chkDefensives, "BOTTOMLEFT", 0, -8)
	
	local chkAdvanced = createCheck("Advanced", getBrowserLocaleString("config_advanced"), configContent, function(self, value) TDTConfig.Advanced = self:GetChecked() end)
	chkAdvanced:SetPoint("TOPLEFT", chkFluff, "BOTTOMLEFT", 0, -8)

	local chkPersonal = createCheck("Personal", getBrowserLocaleString("config_personal"), configContent, function(self, value) TDTConfig.Personal = self:GetChecked() end)
	chkPersonal:SetPoint("TOPLEFT", chkAdvanced, "BOTTOMLEFT", 0, -8)
	
	
	----------------------------
	-- Setup "Dropdown" boxes --
	----------------------------
	-- Dropdown Taint Sucks
	local headerFont = "Fonts\\MORPHEUS.ttf"
	local headerSize = 16
	
	-- Tip Location Selector --
	local locFS = createString(configContent, getBrowserLocaleString("config_tip_location"), headerFont, headerSize)
	locFS:SetPoint("TOPLEFT", chkPersonal, "BOTTOMLEFT", 0, -30)
	
	--locDD = createDropdown(addon.configPanel, "TipLocation", "Show in separate frame", "Show in mob tooltips", "ShowFrame")
	--locDD:SetPoint("TOPLEFT", locFS, "BOTTOMLEFT", 0, -8)
	local locCB = createCheck("Location", getBrowserLocaleString("config_show_separate_frame"), configContent, 
			function(self, value)
				if self:GetChecked() then
					TDTConfig.ShowFrame = "Show in separate frame"
				else
					TDTConfig.ShowFrame = "Show in mob tooltips"
				end
				addon:setEnabled() -- This just clears the addons frame.
				--addon:setMinimized(true) -- Ensures the tip frame is showing.
				addon:setDropdownEnabled() -- This shows / hides a second dropdown based on the current selection.
			end)
	locCB.tooltip = getBrowserLocaleString("config_show_separate_frame_tooltip")
	locCB:SetPoint("TOPLEFT", locFS, "BOTTOMLEFT", 0, -8)

	local showFrameBtn = CreateFrame("Button", "TDTConfigShowFrameBtn", configContent, "UIPanelButtonTemplate")
	showFrameBtn:SetSize(90, 22)
	showFrameBtn:SetPoint("TOPLEFT", locCB, "BOTTOMLEFT", 0, -8)
	showFrameBtn:SetText(getBrowserLocaleString("config_show_frame"))
	showFrameBtn:SetScript("OnClick", function()
		if TDT_ParentFrame then
			TDT_ParentFrame:Show()
			if addon.setMinimized then
				addon:setMinimized(true)
			end
		end
	end)

	local hideFrameBtn = CreateFrame("Button", "TDTConfigHideFrameBtn", configContent, "UIPanelButtonTemplate")
	hideFrameBtn:SetSize(90, 22)
	hideFrameBtn:SetPoint("LEFT", showFrameBtn, "RIGHT", 8, 0)
	hideFrameBtn:SetText(getBrowserLocaleString("config_hide_frame"))
	hideFrameBtn:SetScript("OnClick", function()
		if TDT_ParentFrame then
			TDT_ParentFrame:Hide()
		end
	end)
	
	
	-- Target / Mouseover Selector --
	addon.targetFS = createString(configContent, getBrowserLocaleString("config_target_mouseover"), headerFont, headerSize)
	addon.targetFS:SetPoint("TOPLEFT", locFS, "TOPRIGHT", 70, 0)
	
	--targetDD = createDropdown(addon.configPanel, "TargetMouseover", "Show targeted mob", "Show mouseover", "TargetTrigger")
	--targetDD:SetPoint("TOPLEFT", targetFS, "BOTTOMLEFT", 0, -8)
	addon.chkTarget = createCheck("Target", getBrowserLocaleString("config_show_target"), configContent, 
			function(self, value)
				if self:GetChecked() then
					TDTConfig.TargetTrigger = "Show targeted mob"
				else
					TDTConfig.TargetTrigger = "Show mouseover"
				end
			end)
	addon.chkTarget:SetPoint("TOPLEFT", addon.targetFS, "BOTTOMLEFT", 0, -8)
	
	
	-- Role Selector --
	local roleFS = createString(configContent, getBrowserLocaleString("config_role_specific"), headerFont, headerSize)
	roleFS:SetPoint("TOPLEFT", showFrameBtn, "BOTTOMLEFT", 0, -18)

	local chkMyRoleOnly = createFilterCheck("MyRoleOnly", getBrowserLocaleString("config_show_myroleonly"), configContent,
			function(self, value)
				TDTConfig.RoleFilters.MYROLEONLY = self:GetChecked()
			end)
	chkMyRoleOnly:SetPoint("TOPLEFT", roleFS, "BOTTOMLEFT", 0, -8)

	local chkTankRole = createFilterCheck("RoleTank", getBrowserLocaleString("config_show_tank"), configContent,
			function(self, value)
				TDTConfig.RoleFilters.TANK = self:GetChecked()
			end)
	chkTankRole:SetPoint("TOPLEFT", chkMyRoleOnly, "BOTTOMLEFT", 0, -6)

	local chkHealerRole = createFilterCheck("RoleHealer", getBrowserLocaleString("config_show_healer"), configContent,
			function(self, value)
				TDTConfig.RoleFilters.HEALER = self:GetChecked()
			end)
	chkHealerRole:SetPoint("TOPLEFT", chkTankRole, "BOTTOMLEFT", 0, -6)

	local chkDamageRole = createFilterCheck("RoleDamage", getBrowserLocaleString("config_show_damage"), configContent,
			function(self, value)
				TDTConfig.RoleFilters.DAMAGE = self:GetChecked()
			end)
	chkDamageRole:SetPoint("TOPLEFT", chkHealerRole, "BOTTOMLEFT", 0, -6)
	
	-- Class Selector --
	local classFS = createString(configContent, getBrowserLocaleString("config_class_specific"), headerFont, headerSize)
	classFS:SetPoint("TOPLEFT", roleFS, "TOPRIGHT", 70, 0)

	local chkMyClassOnly = createFilterCheck("MyClassOnly", getBrowserLocaleString("config_show_myclassonly"), configContent,
			function(self, value)
				TDTConfig.ClassFilters.MYCLASSONLY = self:GetChecked()
			end)
	chkMyClassOnly:SetPoint("TOPLEFT", classFS, "BOTTOMLEFT", 0, -8)

	local classCheckRows = {
		{"ClassDruid", string.format("%s DRUID", getBrowserLocaleString("config_show_prefix")), "DRUID"},
		{"ClassHunter", string.format("%s HUNTER", getBrowserLocaleString("config_show_prefix")), "HUNTER"},
		{"ClassMage", string.format("%s MAGE", getBrowserLocaleString("config_show_prefix")), "MAGE"},
		{"ClassPaladin", string.format("%s PALADIN", getBrowserLocaleString("config_show_prefix")), "PALADIN"},
		{"ClassPriest", string.format("%s PRIEST", getBrowserLocaleString("config_show_prefix")), "PRIEST"},
		{"ClassRogue", string.format("%s ROGUE", getBrowserLocaleString("config_show_prefix")), "ROGUE"},
		{"ClassShaman", string.format("%s SHAMAN", getBrowserLocaleString("config_show_prefix")), "SHAMAN"},
		{"ClassWarrior", string.format("%s WARRIOR", getBrowserLocaleString("config_show_prefix")), "WARRIOR"},
		{"ClassWarlock", string.format("%s WARLOCK", getBrowserLocaleString("config_show_prefix")), "WARLOCK"},
	}

	local classFilterChecks = {}
	local previousClassCheck = chkMyClassOnly
	for _, classCheck in ipairs(classCheckRows) do
		local checkboxName = classCheck[1]
		local checkboxLabel = classCheck[2]
		local classKey = classCheck[3]
		local chk = createFilterCheck(checkboxName, checkboxLabel, configContent,
				function(self, value)
					TDTConfig.ClassFilters[classKey] = self:GetChecked()
				end)
		chk:SetPoint("TOPLEFT", previousClassCheck, "BOTTOMLEFT", 0, -6)
		classFilterChecks[classKey] = chk
		previousClassCheck = chk
	end

	local function setCheckLabel(check, text)
		local label = getglobal(check:GetName() .. "Text")
		if label then
			label:SetText(text)
		end
	end
	
	local localeFS = createString(configContent, getBrowserLocaleString("config_language"), headerFont, headerSize)
	localeFS:SetPoint("TOPLEFT", chkDamageRole, "BOTTOMLEFT", 0, -24)

	local localeHelp = createString(configContent, getBrowserLocaleString("config_language_help"), "Fonts\\FRIZQT__.TTF", 11)
	localeHelp:SetPoint("TOPLEFT", localeFS, "BOTTOMLEFT", 0, -4)
	localeHelp:SetWidth(250)

	local localeButton
	localeButton = createCycleButton(configContent, "Locale", {"Auto", "enUS", "deDE"}, function(value)
		local previousValue = TDTConfig.LocaleChoice or "Auto"
		if previousValue == value then
			return
		end

		local dialogInfo = StaticPopupDialogs["TDT_CONFIRM_LOCALE_RELOAD"]
		dialogInfo.text = getBrowserLocaleString("locale_reload_text")
		dialogInfo.button1 = getBrowserLocaleString("locale_reload_accept")
		dialogInfo.button2 = getBrowserLocaleString("locale_reload_cancel")

		local dialog = StaticPopup_Show("TDT_CONFIRM_LOCALE_RELOAD", nil, nil, value)
		if dialog then
			dialog.data2 = {
				previousValue = previousValue,
				dropdown = localeButton,
			}
		else
			localeButton:SetCurrentValue(previousValue)
		end
	end)
	localeButton:SetPoint("TOPLEFT", localeHelp, "BOTTOMLEFT", 0, -8)

	-- Activate in
	-- Tip Location Selector --
	local showinFS = createString(configContent, getBrowserLocaleString("config_content"), headerFont, headerSize)
	showinFS:SetPoint("TOPLEFT", localeButton, "BOTTOMLEFT", 0, -24)
	
	local chkRegDungeons = createCheck("RegDungeons", getBrowserLocaleString("config_show_in_dungeons"), configContent, function(self, value)
		TDTConfig.DungeonToggle = self:GetChecked()
		addon:setEnabled()
	end)
	chkRegDungeons:SetPoint("TOPLEFT", showinFS, "BOTTOMLEFT", 0, -8)
	
	--[[local chkMythicPlus = createCheck("MythicPlus", "Show Tips in Mythic+", addon.configPanel, function(self, value) 
		TDTConfig.MythicPlusToggle = self:GetChecked()
		addon:setEnabled()
		end)
	chkMythicPlus:SetPoint("TOPLEFT", chkRegDungeons, "BOTTOMLEFT", 0, -8)]]--
	
	local chkRaid = createCheck("Raid", getBrowserLocaleString("config_show_in_raid"), configContent, function(self, value) 
		TDTConfig.RaidToggle = self:GetChecked()
		addon:setEnabled()
	end)
	chkRaid:SetPoint("TOPLEFT", chkRegDungeons, "BOTTOMLEFT", 0, -8)

	local minimapButtonFS = createString(configContent, getBrowserLocaleString("config_minimap_button"), headerFont, headerSize)
	minimapButtonFS:SetPoint("TOPLEFT", chkRaid, "BOTTOMLEFT", 0, -18)

	local minimapToggleBtn = CreateFrame("Button", "TDTConfigMinimapToggleBtn", configContent, "UIPanelButtonTemplate")
	minimapToggleBtn:SetSize(180, 22)
	minimapToggleBtn:SetPoint("TOPLEFT", minimapButtonFS, "BOTTOMLEFT", 0, -8)
	minimapToggleBtn:SetScript("OnClick", function()
		TDTConfig.ShowMinimapButton = not (TDTConfig.ShowMinimapButton ~= false)
		if addon.updateMinimapButtonVisibility then
			addon:updateMinimapButtonVisibility()
		end
		local label = TDTConfig.ShowMinimapButton ~= false and getBrowserLocaleString("config_hide_minimap_button") or getBrowserLocaleString("config_show_minimap_button")
		minimapToggleBtn:SetText(label)
	end)

	local chkShowNpcIDs = createCheck("ShowNpcIDs", getBrowserLocaleString("config_show_npc_ids"), configContent, function(self, value)
		TDTConfig.ShowNpcIDs = self:GetChecked()
	end)
	chkShowNpcIDs:SetPoint("TOPLEFT", minimapToggleBtn, "BOTTOMLEFT", 0, -12)
	

	-- Other Stuff
	local OtherFS = createString(configContent, getBrowserLocaleString("config_font_size"), headerFont, headerSize)
	OtherFS:SetPoint("TOPLEFT", previousClassCheck, "BOTTOMLEFT", 0, -24)
	
	--local deleteme = createString(addon.configPanel, "Delete me after", headerFont, headerSize)
	--deleteme:SetPoint("TOPLEFT", OtherFS, "BOTTOMLEFT", 0, -16)
	
	local sliderName = "FontSizeS"
	local fontEdit = CreateFrame("Slider", sliderName, configContent, "OptionsSliderTemplate")
	
	fontEdit:SetWidth(120)
	fontEdit:SetHeight(20)
	fontEdit:SetOrientation('HORIZONTAL')
	fontEdit:SetMinMaxValues(8, 18)
	fontEdit:SetValue(TDTConfig.FontSize)
	fontEdit:SetValueStep(1)
	
	fontEdit.textLow = _G[sliderName.."Low"]
	fontEdit.textHigh = _G[sliderName.."High"]
	fontEdit.text = _G[sliderName.."Text"]
	fontEdit.minValue, fontEdit.maxValue = fontEdit:GetMinMaxValues() 
	fontEdit.textLow:SetText(fontEdit.minValue)
	fontEdit.textHigh:SetText(fontEdit.maxValue)
	fontEdit.text:SetText(TDTConfig.FontSize)
	
	fontEdit.textLow = 8
	fontEdit.textHigh = 14
	--fontEdit.text = "Font Size"
	
	
	fontEdit:SetPoint("TOPLEFT", OtherFS, "BOTTOMLEFT", 0, -22)
	fontEdit:Enable()
	fontEdit:SetScript("OnValueChanged", function(self,event,arg1) 
		
		TDTConfig.FontSize = math.floor(event + 0.5)
		updateTextSize()
		--print(TDTConfig.FontSize)
		self.text:SetText(TDTConfig.FontSize)
			end)

	local function refreshConfigTexts()
		ddTitleString:SetText(getBrowserLocaleString("config_title"))
		setCheckLabel(chkGeneral, getBrowserLocaleString("config_general"))
		setCheckLabel(chkPriority, getBrowserLocaleString("config_priority"))
		setCheckLabel(chkInterrupts, getBrowserLocaleString("config_interrupts"))
		setCheckLabel(chkDefensives, getBrowserLocaleString("config_defensives"))
		setCheckLabel(chkFluff, getBrowserLocaleString("config_fluff"))
		setCheckLabel(chkAdvanced, getBrowserLocaleString("config_advanced"))
		setCheckLabel(chkPersonal, getBrowserLocaleString("config_personal"))
		locFS:SetText(getBrowserLocaleString("config_tip_location"))
		setCheckLabel(locCB, getBrowserLocaleString("config_show_separate_frame"))
		locCB.tooltip = getBrowserLocaleString("config_show_separate_frame_tooltip")
		showFrameBtn:SetText(getBrowserLocaleString("config_show_frame"))
		hideFrameBtn:SetText(getBrowserLocaleString("config_hide_frame"))
		addon.targetFS:SetText(getBrowserLocaleString("config_target_mouseover"))
		setCheckLabel(addon.chkTarget, getBrowserLocaleString("config_show_target"))
		roleFS:SetText(getBrowserLocaleString("config_role_specific"))
		setCheckLabel(chkMyRoleOnly, getBrowserLocaleString("config_show_myroleonly"))
		setCheckLabel(chkTankRole, getBrowserLocaleString("config_show_tank"))
		setCheckLabel(chkHealerRole, getBrowserLocaleString("config_show_healer"))
		setCheckLabel(chkDamageRole, getBrowserLocaleString("config_show_damage"))
		classFS:SetText(getBrowserLocaleString("config_class_specific"))
		setCheckLabel(chkMyClassOnly, getBrowserLocaleString("config_show_myclassonly"))
		for _, classCheck in ipairs(classCheckRows) do
			local classKey = classCheck[3]
			local checkbox = classFilterChecks[classKey]
			if checkbox then
				setCheckLabel(checkbox, string.format("%s %s", getBrowserLocaleString("config_show_prefix"), getLocalizedClassName(classKey)))
			end
		end
		localeFS:SetText(getBrowserLocaleString("config_language"))
		localeHelp:SetText(getBrowserLocaleString("config_language_help"))
		showinFS:SetText(getBrowserLocaleString("config_content"))
		setCheckLabel(chkRegDungeons, getBrowserLocaleString("config_show_in_dungeons"))
		setCheckLabel(chkRaid, getBrowserLocaleString("config_show_in_raid"))
		minimapButtonFS:SetText(getBrowserLocaleString("config_minimap_button"))
		minimapToggleBtn:SetText((TDTConfig and TDTConfig.ShowMinimapButton ~= false) and getBrowserLocaleString("config_hide_minimap_button") or getBrowserLocaleString("config_show_minimap_button"))
		setCheckLabel(chkShowNpcIDs, getBrowserLocaleString("config_show_npc_ids"))
		OtherFS:SetText(getBrowserLocaleString("config_font_size"))
	end
	
	--[[
	
	
	
	local fontEdit = CreateFrame("EditBox", nil, addon.configPanel)
	fontEdit:SetMultiLine(false)
	fontEdit:SetWidth(40)
	fontEdit:SetText(12)
	fontEdit:SetFontObject(ChatFontNormal)
	fontEdit:SetPoint("TOPLEFT", OtherFS, "BOTTOMLEFT", 0, -8)
	fontEdit:SetEnabled(true) ]]--
	--chkRegDungeons:SetChecked(true)
	
	
	
	-- Load in SavedVariables on ADDON_LOADED
	addon.configPanel:RegisterEvent("ADDON_LOADED")
	addon.configPanel:SetScript("OnEvent", function(self, event, arg1)
        if event == "ADDON_LOADED" then
            if arg1 ~= "Tothys-Dungeon-Tips-TBC" then return end

            QEConfig = nil
            TDTConfig = applyConfigDefaults(TDTConfig)
            if type(TDTConfig.FontSize) ~= "number" then
                TDTConfig.FontSize = tonumber(TDTConfig.FontSize) or defaultConfig.FontSize
            end
            if TDTConfig.LocaleChoice ~= "Auto" and TDTConfig.LocaleChoice ~= "enUS" and TDTConfig.LocaleChoice ~= "deDE" then
                TDTConfig.LocaleChoice = defaultConfig.LocaleChoice
            end
            --print(TDTConfig.FontSize)
			
			-- Set default checkbox behaviour
			chkGeneral:SetChecked(TDTConfig.Important)
			chkPriority:SetChecked(TDTConfig.PriorityTargets)
			chkInterrupts:SetChecked(TDTConfig.Interrupts)
			chkDefensives:SetChecked(TDTConfig.Defensives)
			chkFluff:SetChecked(TDTConfig.Fluff)
			chkAdvanced:SetChecked(TDTConfig.Advanced)
			chkPersonal:SetChecked(TDTConfig.Personal)
			--chkMythicPlus:SetChecked(TDTConfig.MythicPlusToggle)
			
			chkRegDungeons:SetChecked(TDTConfig.DungeonToggle)
			chkRaid:SetChecked(TDTConfig.RaidToggle)
			chkShowNpcIDs:SetChecked(TDTConfig.ShowNpcIDs)
			
			-- Set default Drop Down text
			--UIDropDownMenu_SetText(locDD, TDTConfig.ShowFrame)
			--UIDropDownMenu_SetText(targetDD, TDTConfig.TargetTrigger)
			--UIDropDownMenu_SetText(roleDD, TDTConfig.RoleChoice)
			--UIDropDownMenu_SetText(classDD, TDTConfig.ClassChoice)
			-- "Drop downs"
			locCB:SetChecked(TDTConfig.ShowFrame == "Show in separate frame")
			addon.chkTarget:SetChecked(TDTConfig.TargetTrigger == "Show targeted mob")
			chkMyRoleOnly:SetChecked(TDTConfig.RoleFilters.MYROLEONLY)
			chkTankRole:SetChecked(TDTConfig.RoleFilters.TANK)
			chkHealerRole:SetChecked(TDTConfig.RoleFilters.HEALER)
			chkDamageRole:SetChecked(TDTConfig.RoleFilters.DAMAGE)
			chkMyClassOnly:SetChecked(TDTConfig.ClassFilters.MYCLASSONLY)
			for classKey, checkbox in pairs(classFilterChecks) do
				checkbox:SetChecked(TDTConfig.ClassFilters[classKey])
			end
			localeButton:SetCurrentValue(TDTConfig.LocaleChoice)
			
			updateTextSize()
			fontEdit.text:SetText(TDTConfig.FontSize)
			fontEdit:SetValue(TDTConfig.FontSize)
			refreshConfigTexts()
			
			addon:setEnabled()
			addon:setDropdownEnabled()
			if addon.configPanel.refreshScroll then addon.configPanel:refreshScroll() end
		end
	end);

	addon.configPanel:HookScript("OnShow", function()
		refreshConfigTexts()
		if localeButton and TDTConfig then
			localeButton:SetCurrentValue(TDTConfig.LocaleChoice or "Auto")
		end
	end)
	
	-- Add panel to config options
	addon:registerConfigPanel()
	refreshConfigTexts()
	
	-- Proceed
	createTDTFrame()
end

createContentBrowserMenu()
createNpcBrowserMenu()
createDungeonEditorMenu()
createEditorMenu()
createInfoMenu()
createConfigMenu()









